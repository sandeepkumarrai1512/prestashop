<?php
/**
* 2007-2019 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author    PrestaShop SA <contact@prestashop.com>
*  @copyright 2007-2019 PrestaShop SA
*  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

require_once(_PS_MODULE_DIR_ . 'businessdirectories/classes/AdsListing.php');
class BusinessdirectoriesListAllAdsModuleFrontController extends ModuleFrontControllerCore
{
    public function init()
    {
        $this->page_name = 'List Ads';
        $this->disableBlocks();
        parent::init();
    }

    protected function disableBlocks()
    {
        $this->display_column_left = false;
    }

    public function initContent()
    {
        parent::initContent();
        $base_url = Tools::getHttpHost(true).__PS_BASE_URI__;
        if (!$this->context->customer->isLogged() && $this->php_self != 'authentication' && $this->php_self != 'password') {
            Tools::redirect('index.php?controller=authentication?back=my-account');
        } else {
			$object = new AdsListing();
			$limit = 10;
			$page_no = (!empty(Tools::getValue('page_no'))) ? Tools::getValue('page_no') : 1;
			$offset = ($page_no-1) * $limit;
            $total_ads = $object->countads((int)$this->context->customer->id);
            $total_pages = ceil($total_ads['total_ads'] / $limit);
            $all_ads = $object->listallads((int)$this->context->customer->id, $offset, $limit);


	    
            $ads_listing = array();
            foreach ($all_ads as $single_ad) {

                $images = $object->getImages($single_ad['id_ad']);
		 
		if($images):
                $single_ad['all_images'] = $images;
		else:
		$single_ad['all_images'] = '';
		endif;
                $ads_listing[] = $single_ad;

            }

                     
            $this->context->smarty->assign(array(
                'list_ads' => $ads_listing,
                'base_url' => $base_url,
                'page_no' => $page_no,
                'total_pages' => $total_pages,
                'success' => (!empty($this->context->cookie->updatead)) ? $this->context->cookie->updatead : ''
            ));
            if (Businessdirectories::isPs17()) {
                $this->setTemplate('module:businessdirectories/views/templates/front/list-my-ads.tpl');
            } else {
                $this->setTemplate('list-my-ads-1-6.tpl');
            }
            unset($this->context->cookie->updatead);
            
            if (!empty(Tools::getValue('type'))) {
				Db::getInstance()->delete('businessdirectories_ads', 'id_ad = '.(int)Tools::getValue('id_ad'));
				Db::getInstance()->delete('businessdirectories_ad_types', 'id_ad = '.(int)Tools::getValue('id_ad'));
				Db::getInstance()->delete('businessdirectories_ad_tags', 'id_ad = '.(int)Tools::getValue('id_ad'));
				Db::getInstance()->delete('businessdirectories_ad_images', 'id_ad = '.(int)Tools::getValue('id_ad'));
                $this->context->smarty->assign(array(
                    'success' => 'Ad Successfully deleted',
                ));
                Tools::redirect($base_url.'my-account/listads');
            }
        }
    }
    
    /**
     * @return array
     */
    public function getBreadcrumbLinks()
    {
        $breadcrumb = parent::getBreadcrumbLinks();
        $breadcrumb['links'][] = $this->addMyAccountToBreadcrumb();

        return $breadcrumb;
    }
}
