/**
* 2007-2019 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author    PrestaShop SA <contact@prestashop.com>
*  @copyright 2007-2019 PrestaShop SA
*  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*
* Don't forget to prefix your containers with your own identifier
* to avoid any conflicts with others containers.
*/

$(document).ready(function() {

    
    // Multiple images preview in browser
    var imagesPreview = function(input, placeToInsertImagePreview) {

        if (input.files) {
            var filesAmount = input.files.length;
            for (i = 0; i < filesAmount; i++) {
                var reader = new FileReader();
                reader.onload = function(event) {
                    $($.parseHTML('<img style="width:100px;margin-right:10px;">')).attr('src', event.target.result).appendTo(placeToInsertImagePreview);

                    
                }
                reader.readAsDataURL(input.files[i]);
            }
        }

    };

    $('#ad_images').on('change', function() {
        $("#gallery").html('');
        imagesPreview(this, 'div#gallery');
    });  
});

function chooseExistingImages(customer_id) {
    var modal = document.getElementById("myModal");
    modal.style.display = "block";
    return false;
}

function closePopup() {
    var modal = document.getElementById("myModal");
    
    modal.style.display = "none";


}

function cancelPopup() {
    var modal = document.getElementById("myModal");
    $('#myModal .modal-content p input:checkbox').removeAttr('checked'); 
    $("#existing_images").val('');
    modal.style.display = "none";
}


function chooseimg() {
    var selected_images = $.map($(':checkbox[name=all_existing_images\\[\\]]:checked'), function(n, i){
      return n.value;
}).join(',');
    $("#existing_images").val(selected_images);
}

function validateinput()
{
    var inputbox = document.getElementById("price_start");
    if(isNaN(parseFloat(inputbox.value)))
    {
        $("#price_start").val('');
    }
}

function validateinputPriceEnd()
{
    var inputbox = document.getElementById("price_end");
    if(isNaN(parseFloat(inputbox.value)))
    {
        $("#price_end").val('');
    }
}

$( function() {
    $( "#datepicker" ).datepicker({  dateFormat: 'yy-mm-dd' });
  } );


/****select box dropdown****/
$(document).ready(function() {

    //$("#ad_images").on("change", function(e){
        /*if($('#ad_images').val()) {
            
            e.preventDefault();
            $('#loader-icon').show();
            $(this).ajaxSubmit({ 
                target:   '#targetLayer', 
                beforeSubmit: function() {
                  $("#progress-bar").width('0%');
                },
                uploadProgress: function (event, position, total, percentComplete){ 
                    $("#progress-bar").width(percentComplete + '%');
                    $("#progress-bar").html('<div id="progress-status">' + percentComplete +' %</div>')
                },
                success:function (){
                    $('#loader-icon').hide();
                },
                resetForm: true 
            }); 
            return false; 
        }*/
        //alert('test......');
        /*e.preventDefault();  
        
        

        var form = $('form')[0]; // You need to use standard javascript object here
        //var formData = new FormData(form);
        
        

       var formData = new FormData();
        
        // Attach file
        formData.append('images', $('input[type=file]')[0].files[0]); 

        $.ajax({
        url: $(this).attr('action'),
        data: formData,
        type: 'POST',
        contentType: false, // NEEDED, DON'T OMIT THIS (requires jQuery 1.6+)
        processData: false, // NEEDED, DON'T OMIT THIS
        dataType: 'json',
        xhr: function(){
    //upload Progress
    var xhr = $.ajaxSettings.xhr();
    if (xhr.upload) {
      xhr.upload.addEventListener('progress', function(event) {
        var percent = 0;
        var position = event.loaded || event.position;
        var total = event.total;
        if (event.lengthComputable) {
          percent = Math.ceil(position / total * 100);
        }
        //update progressbar
        $("#upload-progress .progress-bar").css("width", + percent +"%");
      }, true);
    }
    return xhr;
  }
    }).done(function(response){ 
        $("#upload-progress .progress-bar").css("width", "0");
        $("#server-results").html(response);
        
    });*/


    //});

$('#myModal .modal-content p img').click(function() {
    
   if($(this).closest('p').find('input[type=checkbox]').is(':checked')) {
  $(this).closest('p').find('input[type=checkbox]').prop('checked', false);
   
  } else {
  
  $(this).closest('p').find('input[type=checkbox]').prop('checked', true);
  }
});

$(".js-select2").select2({
            closeOnSelect : false,
            placeholder : "Placeholder",
            allowHtml: true,
            allowClear: true,
            tags: true // создает новые опции на лету
        });

        $('.icons_select2').select2({
                width: "100%",
                templateSelection: iformat,
                templateResult: iformat,
                allowHtml: true,
                placeholder: "Placeholder",
                dropdownParent: $( '.select-icon' ),//обавили класс
                allowClear: true,
                multiple: false
            });
    

                function iformat(icon, badge) {
                    var originalOption = icon.element;
                    var originalOptionBadge = $(originalOption).data('badge');
                 
                    return $('<span><i class="fa ' + $(originalOption).data('icon') + '"></i> ' + icon.text + '<span class="badge">' + originalOptionBadge + '</span></span>');
                }
            });

/*var abc = 0; //Declaring and defining global increement variable

$(document).ready(function() {

//To add new input file field dynamically, on click of "Add More Files" button below function will be executed
    $('#add_more').click(function() {
        $(this).before($("<div/>", {id: 'filediv'}).fadeIn('slow').append(
                $("<input/>", {name: 'file[]', type: 'file', id: 'file'}),        
                $("<br/><br/>")
                ));
    });

//following function will executes on change event of file input to select different file   
$('body').on('change', '#file', function(){
            if (this.files && this.files[0]) {
                 abc += 1; //increementing global variable by 1
                
                var z = abc - 1;
                var x = $(this).parent().find('#previewimg' + z).remove();
                $(this).before("<div id='abcd"+ abc +"' class='abcd'><img id='previewimg" + abc + "' src=''/></div>");
               
                var reader = new FileReader();
                reader.onload = imageIsLoaded;
                reader.readAsDataURL(this.files[0]);
               
                $(this).hide();
                $("#abcd"+ abc).append($("<img/>", {id: 'img', src: 'x.png', alt: 'delete'}).click(function() {
                $(this).parent().parent().remove();
                }));
            }
        });

//To preview image     
    function imageIsLoaded(e) {
        $('#previewimg' + abc).attr('src', e.target.result);
    };

    $('#upload').click(function(e) {
        var name = $(":file").val();
        if (!name)
        {
            alert("First Image Must Be Selected");
            e.preventDefault();
        }
    });
});*/

/*****end select box****/
