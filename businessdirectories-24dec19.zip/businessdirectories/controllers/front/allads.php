<?php
/**
* 2007-2019 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author    PrestaShop SA <contact@prestashop.com>
*  @copyright 2007-2019 PrestaShop SA
*  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

require_once(_PS_MODULE_DIR_ . 'businessdirectories/classes/AllAds.php');
class BusinessdirectoriesAllAdsModuleFrontController extends ModuleFrontControllerCore
{
    public function init()
    {
        $this->page_name = 'All Ads';
        $this->disableBlocks();
        parent::init();


    }

    protected function disableBlocks()
    {
        $this->display_column_left = false;
    }

    public function initContent()
    {
        parent::initContent();
        $object = new AllAds();
        $getallTags = $object->getallTags();
        $getadsType = $object->getadsType();

        $base_url = Tools::getHttpHost(true).__PS_BASE_URI__;
        $limit = 200;
        $page_no = (!empty(Tools::getValue('page_no'))) ? Tools::getValue('page_no') : 1;
        $offset = ($page_no-1) * $limit;
        $search_ad_type = array();
        $search_ad_tag = array();
        if ( isset( $_REQUEST['searchAd']  ) )  {
            

           
                $type_where = '';
                $tag_where = '';
                $and_condition = '';
                if (!empty($_REQUEST['adstype']) && !empty($_REQUEST['tags'])) {
                    $and_condition = ' AND ';
                }
                $select = 'SELECT ads.*, c.`firstname`, c.`lastname` FROM `'._DB_PREFIX_.'businessdirectories_ads` ads';
                $join = ' INNER JOIN `'._DB_PREFIX_.'customer` as c ON (c.`id_customer`=ads.id_customer)';
                if (!empty($_REQUEST['adstype'])) {
                    $search_ad_type = implode(',', $_REQUEST['adstype']);
                    $join .= ' INNER JOIN `'._DB_PREFIX_.'businessdirectories_ad_types` adstype 
                    ON  (ads.`id_ad` = adstype.`id_ad`)';
                    $type_where = 'adstype.`id_type` IN ('.implode(',', $_REQUEST['adstype']).')';
                    $search_ad_type = $_REQUEST['adstype'];
                }
                if (!empty($_REQUEST['tags'])) {
                    $search_ad_tag = implode(',', $_REQUEST['tags']);
                    $join .= ' INNER JOIN `'._DB_PREFIX_.'businessdirectories_ad_tags` tags 
                    ON  (ads.`id_ad` = tags.`id_ad`)';
                    $tag_where = 'tags.`id_tag` IN ('.implode(',', $_REQUEST['tags']).')';
                    $search_ad_tag = $_REQUEST['tags'];
                }
                    
                $sql = $select.$join.' where '.$type_where.$and_condition.$tag_where.' GROUP BY ads.`id_ad` ORDER by ads.`id_ad` DESC';
              
                $total_records = Db::getInstance()->executeS($sql);                                

                $total_pages = ceil(count($total_records) / $limit);
                $get_records = $select.$join.' where '.$type_where.$and_condition.$tag_where.' GROUP BY ads.`id_ad` ORDER by ads.`id_ad` DESC LIMIT '.$offset.','.$limit;


                $all_ads = Db::getInstance()->executeS($get_records);
                
                $ads_listing = array();
                if (!empty($all_ads)) {
                    foreach ($all_ads as $single_ad) {
                        $images = $object->getImages($single_ad['id_ad']);
                        $single_ad['all_images'] = $images;
                        $ads_listing[] = $single_ad;
                    }
                }

        } else {
            $total_ads = $object->countads();
            $total_pages = ceil($total_ads['total_ads'] / $limit);

            $all_ads = $object->listallads( $offset, $limit);



            

            /*$ads_listing = array();
            foreach ($all_ads as $single_ad) {
                
                $images = $object->getImages($single_ad['id_ad']);
                $single_ad['all_images'] = $images;
                $ads_listing[] = $single_ad;

            }*/

            $ads_listing = array();
            foreach ($all_ads as $single_ad) {

                $images = $object->getImages($single_ad['id_ad']);
         
        if($images):
                $single_ad['all_images'] = $images;
        else:
        $single_ad['all_images'] = '';
        endif;
                $ads_listing[] = $single_ad;

            }
            

        }

        //print_r($search_ad_type);

        $this->context->smarty->assign(array(
            'list_ads' => $ads_listing,
            'base_url' => $base_url,
            'getalltags' => $getallTags,
            'is_logged'  => (bool)$this->context->customer->isLogged(),
            'getadsType' => $getadsType,
            'page_no' => $page_no,
            'total_pages' => $total_pages,
            'search_ad_type' => $search_ad_type,
            'search_ad_tag' => $search_ad_tag
        ));
        if (Businessdirectories::isPs17()) {
            $this->setTemplate('module:businessdirectories/views/templates/front/all-ads.tpl');
        } else {
            $this->setTemplate('list-my-ads-1-6.tpl');
        }
    }
    
    /**
     * @return array
     */
    public function getBreadcrumbLinks()
    {
        $breadcrumb = parent::getBreadcrumbLinks();
        $breadcrumb['links'][] = $this->addMyAccountToBreadcrumb();

        if($this->context->customer->isLogged()){

        return $breadcrumb;
    }
    }
}
