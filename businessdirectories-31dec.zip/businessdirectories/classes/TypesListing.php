<?php
/**
* 2010-2018 Webkul.
*
* NOTICE OF LICENSE
*
* All right is reserved,
* Please go through this link for complete license : https://store.webkul.com/license.html
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade this module to newer
* versions in the future. If you wish to customize this module for your
* needs please refer to https://store.webkul.com/customisation-guidelines/ for more information.
*
*  @author    Webkul IN <support@webkul.com>
*  @copyright 2010-2018 Webkul IN
*  @license   https://store.webkul.com/license.html
*/

class TypesListing extends ObjectModel
{
    public $name;
    public $date_add;

    public static $definition = array(
        'table' => 'businessdirectories_types',
        'primary' => 'id_type',
        'fields' => array(
            'name' => array('type' => self::TYPE_STRING),
            'date_add' => array('type' => self::TYPE_STRING),
        ),
    );

    public function delete()
    {
        $deleteAdType = Db::getInstance()->execute(
            'DELETE FROM `'._DB_PREFIX_.'businessdirectories_types`
            WHERE `id_type` = '.(int) $this->id
        );

        if (!$deleteAdType || !parent::delete()) {
            return false;
        }

        return true;
    }

    /**
     * Get payment modes created by admin for seller
     *
     * @return array
     */
    public static function getAdTypes()
    {   
        return Db::getInstance()->executeS('SELECT * FROM `'._DB_PREFIX_.'businessdirectories_types`');
    }

    public static function getAdShippings()
    {   
        return Db::getInstance()->executeS('SELECT * FROM `'._DB_PREFIX_.'businessdirectories_shipping`');
    }

    /**
     * Get Product Clone Information
     *
     * @return array
     */
    public function typeNameExistOrNot($name)
    {
        return Db::getInstance()->getRow('SELECT id_type,name FROM `'._DB_PREFIX_.'businessdirectories_types` where name="'.trim($name).'"');
    }
    
    /**
     * Get Product Clone Information Using Product Id
     *
     * @return array
     */
    public function getAllProductsCloneInfoProduct($product_id)
    {
        return Db::getInstance()->getRow('SELECT * FROM `'._DB_PREFIX_.'fnacpricerule_product_copies` where id_product="'.$product_id.'" ORDER BY id_fnacpricerule DESC');
    }
    
    /**
     * Get All Product Clones Information
     *
     * @return array
     */
    public function getAdTypeInfo($id)
    {
        return Db::getInstance()->getRow('SELECT * FROM `'._DB_PREFIX_.'businessdirectories_types` where id_type='.$id);
    }

    /**
     * Get Tag Exist Or Not
     *
     * @return array
     */
    public function checkTagExistOrNot($tag_name)
    {
        return Db::getInstance()->getRow('SELECT id_tag FROM `'._DB_PREFIX_.'businessdirectories_tags` where name="'.$tag_name.'"');
    }
    
    public function getAllImages($id_customer)
    {
        //return Db::getInstance()->executeS('SELECT * FROM `'._DB_PREFIX_.'businessdirectories_images` where id_customer="'.$id_customer.'" AND `type` < 1');
	return Db::getInstance()->executeS('SELECT * FROM `'._DB_PREFIX_.'businessdirectories_images` where id_customer="'.$id_customer.'"');
    }
    public function getAllVideos($id_customer)
    {
        return Db::getInstance()->executeS('SELECT * FROM `'._DB_PREFIX_.'businessdirectories_images` where id_customer="'.$id_customer.'" AND `type` =1');
    }
    
    public function getAdTags($id_ad)
    {
		return Db::getInstance()->executeS('SELECT bt.name FROM `'._DB_PREFIX_.'businessdirectories_ad_tags` as bat INNER JOIN `'._DB_PREFIX_.'businessdirectories_tags`as bt ON (bt.id_tag=bat.id_tag) where bat.id_ad="'.$id_ad.'"');
    }
    
    public function getAdvTypes($id_ad)
    {
		return Db::getInstance()->executeS('SELECT bt.id_type, bt.name FROM `'._DB_PREFIX_.'businessdirectories_ad_types` as bat INNER JOIN `'._DB_PREFIX_.'businessdirectories_types`as bt ON (bt.id_type=bat.id_type) where bat.id_ad="'.$id_ad.'"');
    }

    public function getAdvShippings($id_ad)
    {
        return Db::getInstance()->executeS('SELECT st.id_shipping, st.name FROM `'._DB_PREFIX_.'businessdirectories_ad_shipping` as sat INNER JOIN `'._DB_PREFIX_.'businessdirectories_shipping`as st ON (st.id_shipping=sat.id_shipping) where sat.id_ad="'.$id_ad.'"');
    }
    
    public function getAdvimages($id_ad)
    {
		return Db::getInstance()->executeS('SELECT bi.id_image, bi.name FROM `'._DB_PREFIX_.'businessdirectories_ad_images` as bai INNER JOIN `'._DB_PREFIX_.'businessdirectories_images`as bi ON (bi.id_image=bai.id_image) where bai.id_ad="'.$id_ad.'"');
    }

    public function singleViewimages($id_ad)
    {
        return Db::getInstance()->executeS('SELECT bi.id_image, bi.name FROM `'._DB_PREFIX_.'businessdirectories_ad_images` as bai INNER JOIN `'._DB_PREFIX_.'businessdirectories_images`as bi ON (bi.id_image=bai.id_image) where bai.id_ad="'.$id_ad.'" AND bi.`type` < 1');
        
    }

    public function getAdvideos($id_ad)
    {
        return Db::getInstance()->executeS('SELECT bi.id_image, bi.name FROM `'._DB_PREFIX_.'businessdirectories_ad_images` as bai INNER JOIN `'._DB_PREFIX_.'businessdirectories_images`as bi ON (bi.id_image=bai.id_image) where bai.id_ad="'.$id_ad.'" AND bi.`type` = 1');
    }

    public function getAdvideosByadsId($id_ad)
    {
        return Db::getInstance()->executeS('SELECT bi.id_image as video_id, bi.name FROM `'._DB_PREFIX_.'businessdirectories_ad_images` as bai INNER JOIN `'._DB_PREFIX_.'businessdirectories_images`as bi ON (bi.id_image=bai.id_image) where bai.id_ad="'.$id_ad.'" AND bi.`type` = 1');
    }
}
