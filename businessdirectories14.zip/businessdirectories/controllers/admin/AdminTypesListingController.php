<?php
/**
* 2007-2019 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author    PrestaShop SA <contact@prestashop.com>
*  @copyright 2007-2019 PrestaShop SA
*  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

require_once _PS_MODULE_DIR_.'businessdirectories/classes/TypesListing.php';
class AdminTypesListingController extends ModuleAdminController
{
    private $postErrors = array();
    public function __construct()
    {
        $this->bootstrap = true;
        $this->table = 'businessdirectories_types';
        $this->className = 'TypesListing';
        $this->identifier = 'id_type';
        parent::__construct();
        $this->toolbar_title = $this->l('Manage All Ad Types');

        $this->fields_list = array(
            'id_type' => array(
                'title' => $this->l('ID'),
                'align' => 'center',
                'class' => 'fixed-width-xs',
                'search' => false,
                'remove_onclick' => true,
            ),
            'name' => array(
                'title' => $this->l('Name'),
                'width' => '100',
                'remove_onclick' => true,
            ),
            'date_add' => array(
                'title' => $this->l('Created date'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
        );
        $this->bulk_actions = array(
            'delete' => array('text' => $this->l('Delete selected'),
                'icon' => 'icon-trash',
                'confirm' => $this->l('Delete selected Ad Type?'),
            ),
        );
    }

    /**
     * Initialize Header Toolbar
     */
    public function initToolbar()
    {
        parent::initToolbar();
        $this->page_header_toolbar_btn['new'] = array(
            'href' => $this->context->link->getAdminLink('AdminAdType'),
            'desc' => $this->l('Add New Ad Type'),
        );
    }

    /**
     * Initialize Results Action
     */
    public function renderList()
    {
        //$this->addRowAction('edit');
        $this->addRowAction('delete');
        return parent::renderList();
    }
}
