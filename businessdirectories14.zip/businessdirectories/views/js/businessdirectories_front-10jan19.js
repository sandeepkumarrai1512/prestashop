/**
* 2007-2019 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author    PrestaShop SA <contact@prestashop.com>
*  @copyright 2007-2019 PrestaShop SA
*  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*
* Don't forget to prefix your containers with your own identifier
* to avoid any conflicts with others containers.
*/

$(document).ready(function() {

    $('.tabcontent .add').click(function() {
    $('.block:last').before('<div class="block"><input type="text" /><span class="remove">Remove Option</span></div>');
});
$('.optionBox').on('click','.remove',function() {
    $(this).parent().remove();
});

    $(document).on("click",".remove_image",function() {     
     var delid = $(this).data('delid');
     $(this).parent().remove();
    $(this).siblings().remove();    
    $(this).remove();
    

     var delexistingid = $("#hiddenimages").val();
     var arr = delexistingid.split( ',' );
     var removeItem = delid;

    arr = jQuery.grep(arr, function(value) {
      return value != removeItem;
    });
     
     $("#hiddenimages").val(arr);


     
     //$("#hiddenimages").val('');

     $.ajax({  
     type: "post",
     url: $(this).attr('action'),
     data: "delid="+delid,
     dataType: 'json',

     success: function(data){
     //console.log(data); 
     if(data.status == 1){

     }  
    }
});

      });

    
    // Multiple images preview in browser
    var imagesPreview = function(input, placeToInsertImagePreview) {

        if (input.files) {
            var filesAmount = input.files.length;
            for (i = 0; i < filesAmount; i++) {
                var reader = new FileReader();
                reader.onload = function(event) {
                    $($.parseHTML('<img style="width:150px;height:100px;margin-right:10px;">')).attr('src', event.target.result).appendTo(placeToInsertImagePreview);

                    
                }
                reader.readAsDataURL(input.files[i]);
            }
        }

    };

    $('#ad_images').on('change', function() {
        $("#gallery").html('');
        //imagesPreview(this, 'div#gallery');
    });  
});

function chooseExistingImages(customer_id) {
    var modal = document.getElementById("myModal");
    modal.style.display = "block";
    return false;
}

function closePopup() {
    var modal = document.getElementById("myModal");
    
    modal.style.display = "none";


}

function cancelPopup() {
    var modal = document.getElementById("myModal");
    $('#myModal .modal-content p input:checkbox').removeAttr('checked'); 
    $("#existing_images").val('');
    modal.style.display = "none";
}

var all_img_ids = new Array();
function chooseimg(str) {
		if($("#image_checkbox_"+str).is(":checked")){
			all_img_ids.push(str);
            
            
		} else {
			all_img_ids.splice( $.inArray(str,all_img_ids) ,1 );
            
            
		}
	
	var selected_images = $.map($(':checkbox[name=all_existing_images\\[\\]]:checked'), function(n, i){
      return n.value;
}).join(',');
    $("#existing_images").val(selected_images);
    if (all_img_ids.toString() != '') {
		var base_url = $("#baseurl").val();
		var existing_images = all_img_ids.toString();
		$.ajax({
			type: "POST",
			url: base_url+'modules/businessdirectories/ajax-call.php',
			data: 'existing_images='+existing_images+'&type=showexistingimages&base_url='+base_url,
			success: function (data) {
				$("#existing_choose_gallery").html(data);
			},
		});
	} else {
        if( $("#existing_choose_gallery").val()!=="" ) {


		$("#existing_choose_gallery").html(data);
    }else{
        $("#existing_choose_gallery").html('');
        alert('no data..');
    }
	}
}

function validateinput()
{
    var inputbox = document.getElementById("price_start");
    if(isNaN(parseFloat(inputbox.value)))
    {
        $("#price_start").val('');
    }
}

function validateinputPriceEnd()
{
    var inputbox = document.getElementById("price_end");
    if(isNaN(parseFloat(inputbox.value)))
    {
        $("#price_end").val('');
    }
}

$( function() {
    $( "#datepicker" ).datepicker({  dateFormat: 'yy-mm-dd', minDate: 0 }).datepicker( "setDate", new Date());
  } );


function changedate(){
	if($('.never_expire_date').is(":checked")){
		var dateString = '0000-00-00';
	} else {
		var date = new Date();
        var dateString = new Date(date.getTime() - (date.getTimezoneOffset() * 60000 ))
                    .toISOString()
                    .split("T")[0];
	}
	$("#datepicker").val(dateString);
}

function choose_img(str){
	$("#image_checkbox_"+str).trigger('click');
	/*var base_url = $("#baseurl").val();
	var existing_images = $("#new_images").val();
	$.ajax({
        type: "POST",
        url: base_url+'modules/businessdirectories/ajax-call.php',
        data: 'existing_images='+existing_images+'&type=showexistingimages&base_url='+base_url,
        success: function (data) {
            $("#existing_choose_gallery").html(data);
        },
    });*/
}

/****select box dropdown****/
$(document).ready(function() {
    
    $('.small-img li').click(function () {

    var imgdatatype = $(this).data('type');

    if(imgdatatype =='image') {
        var imgsrc = $(this).find('img').attr('src');
        $('.small-img li').removeClass('active');
        $(this).addClass('active');
        $(".full-image-sec iframe").hide();        
        $(".full-image-sec img").attr("src", imgsrc);
        $(".full-image-sec img").show();
    }
    else if (imgdatatype =='video'){
        var imgsrc = $(this).find('source').each(function() {
        var vidsource = $(this).attr('src');
        $(".full-image-sec iframe").attr("src", vidsource);
        $(".full-image-sec iframe").show();        
        $(".full-image-sec img").hide();

        });
       
  
}
    });

    	
	$("#ad_images").on("change", function(e){

        e.preventDefault(); 
        $('.myprogress').css('width', '0');

       
        //var form = $('form')[0];
         // You need to use standard javascript object here
        //var formData = new FormData(form);
        var formData = new FormData();
        var hiddenimages = $("#hiddenimages").val();
        var existingid = $("#hiddenimages");
        var baseurl = $("#baseurl").val();
        
        // Attach file
        formData.append('images', $('input[type=file]')[0].files[0] ); 
        formData.append('hiddenimages', hiddenimages ); 


        $.ajax({
			url: $(this).attr('action'),
			data: formData,
			type: 'POST',
			contentType: false, // NEEDED, DON'T OMIT THIS (requires jQuery 1.6+)
			processData: false, // NEEDED, DON'T OMIT THIS
			cache: false,
			dataType: 'json',
			xhr: function () {
                            var xhr = new window.XMLHttpRequest();
                            xhr.upload.addEventListener("progress", function (evt) {
                                if (evt.lengthComputable) {
                                    var percentComplete = evt.loaded / evt.total;
                                    percentComplete = parseInt(percentComplete * 100);
                                    $('.myprogress').text(percentComplete + '%');
                                    $('.myprogress').css('width', percentComplete + '%');
                                }
                            }, false);
                            return xhr;
                        },
			
			success: function(response){
                console.log(response);
				
                if( $("#hiddenimages").val() ) {
                
                existingid.val( existingid.val()+','+response.id   );

            }
                else  {
                $("#hiddenimages").val(response.id);
            } 
                
				if(response.status == 1){
                if(response.type == 1){
                $("#gallerynew").append('<div  class="newgall_images"><video width="100%" height="100%" controls><source src="'+baseurl+'modules/businessdirectories/uploads/'+response.imgsrc+'" type="video/mp4"></video><img data-delid="'+response.id+'" class="remove_image" src="'+baseurl+'modules/businessdirectories/uploads/x.png" alt="remove" /></div>');
                 }
                    else
                    {

                    

					$("#gallerynew").append('<div  class="newgall_images"><img style="width:280px;height:158px;margin-right:10px;" src="'+baseurl+'modules/businessdirectories/uploads/'+response.imgsrc+'" /><img data-delid="'+response.id+'" class="remove_image" src="'+baseurl+'modules/businessdirectories/uploads/x.png" alt="remove" /></div>');
				}
            $("#message_response").text(response.msg);

            setTimeout(function() {
    $('#message_response').text('');
    }, 30000); //time in milliseconds

            } else if(response.status == 0){
            $("#message_response").text(response.msg);

            }
        /*setTimeout(function() {
    $('#message_response').fadeOut('fast');
    }, 30000); //time in milliseconds*/



                
            }
        
    });


    });

$(".js-select2").select2({
            closeOnSelect : false,
            placeholder : "Placeholder",
            allowHtml: true,
            allowClear: true,
            tags: true // создает новые опции на лету
        });

        $('.icons_select2').select2({
                width: "100%",
                templateSelection: iformat,
                templateResult: iformat,
                allowHtml: true,
                placeholder: "Placeholder",
                dropdownParent: $( '.select-icon' ),//обавили класс
                allowClear: true,
                multiple: false
            });
    

                function iformat(icon, badge) {
                    var originalOption = icon.element;
                    var originalOptionBadge = $(originalOption).data('badge');
                 
                    return $('<span><i class="fa ' + $(originalOption).data('icon') + '"></i> ' + icon.text + '<span class="badge">' + originalOptionBadge + '</span></span>');
                }
            });

/*****end select box****/
