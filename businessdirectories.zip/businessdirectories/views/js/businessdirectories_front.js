/**
* 2007-2019 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author    PrestaShop SA <contact@prestashop.com>
*  @copyright 2007-2019 PrestaShop SA
*  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*
* Don't forget to prefix your containers with your own identifier
* to avoid any conflicts with others containers.
*/

$(document).ready(function() {
	// Multiple images preview in browser
    var imagesPreview = function(input, placeToInsertImagePreview) {
        if (input.files) {
            var filesAmount = input.files.length;
            for (i = 0; i < filesAmount; i++) {
                var reader = new FileReader();
                reader.onload = function(event) {
                    $($.parseHTML('<img style="width:50px;margin-right:10px;">')).attr('src', event.target.result).appendTo(placeToInsertImagePreview);
                }
                reader.readAsDataURL(input.files[i]);
            }
        }
    };

    $('#ad_images').on('change', function() {
		$("#gallery").html('');
        imagesPreview(this, 'div#gallery');
    });  
});

function chooseExistingImages(customer_id) {
	var modal = document.getElementById("myModal");
	modal.style.display = "block";
	return false;
}

function closePopup() {
	var modal = document.getElementById("myModal");
	modal.style.display = "none";
}

function chooseimg() {
    var selected_images = $.map($(':checkbox[name=all_existing_images\\[\\]]:checked'), function(n, i){
      return n.value;
}).join(',');
	$("#existing_images").val(selected_images);
}

function validateinput()
{
    var inputbox = document.getElementById("price_start");
    if(isNaN(parseFloat(inputbox.value)))
    {
        $("#price_start").val('');
    }
}

function validateinputPriceEnd()
{
    var inputbox = document.getElementById("price_end");
    if(isNaN(parseFloat(inputbox.value)))
    {
        $("#price_end").val('');
    }
}
