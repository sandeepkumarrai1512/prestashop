<?php
/**
* 2010-2018 Webkul.
*
* NOTICE OF LICENSE
*
* All right is reserved,
* Please go through this link for complete license : https://store.webkul.com/license.html
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade this module to newer
* versions in the future. If you wish to customize this module for your
* needs please refer to https://store.webkul.com/customisation-guidelines/ for more information.
*
*  @author    Webkul IN <support@webkul.com>
*  @copyright 2010-2018 Webkul IN
*  @license   https://store.webkul.com/license.html
*/

class FeaturesGroupListing extends ObjectModel
{
    public $id_parent_feature_group;
    public $features;

    public static $definition = array(
        'table' => 'featuresgroup',
        'primary' => 'id_featuresgroup',
        'fields' => array(
            'id_parent_feature_group' => array('type' => self::TYPE_INT),
            'features' => array('type' => self::TYPE_STRING),
        ),
    );

    public function delete()
    {
		
        $deleteAssignedFeatures = Db::getInstance()->execute(
            'DELETE FROM `'._DB_PREFIX_.'featuresgroup`
            WHERE `id_featuresgroup` = '.(int) $this->id
        );

        if (!$deleteAssignedFeatures || !parent::delete()) {
            return false;
        }

        return true;
    }

    /**
     * Get payment modes created by admin for seller
     *
     * @return array
     */
    public static function getFeaturesGroup()
    {
        return Db::getInstance()->executeS('SELECT * FROM `'._DB_PREFIX_.'featuresgroup`');
    }    
}
