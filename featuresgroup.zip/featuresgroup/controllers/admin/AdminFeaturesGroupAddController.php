<?php
/**
* 2007-2019 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author    PrestaShop SA <contact@prestashop.com>
*  @copyright 2007-2019 PrestaShop SA
*  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

class AdminFeaturesGroupAddController extends ModuleAdminController
{
    public $content = '';
    private $postErrors = array();
    public function __construct()
    {
        $this->context = Context::getContext();
        $this->bootstrap = true;

        parent::__construct();
        $this->toolbar_title = $this->l('Create Parent Group');
    }

    /**
     * Initialize Content
     */
    public function initContent()
    {
		if (!empty($this->context->cookie->error)) {
			$this->context->smarty->assign(array(
				'status' => $this->context->cookie->error,
				'type' => 'error',
			));
			$second_part_url = 'featuresgroup/views/templates/admin/status.tpl';
            $this->content .= $this->context->smarty->fetch(_PS_MODULE_DIR_.pSQL($second_part_url));
        } if (!empty($this->context->cookie->parent_group_saved)) {
			$this->context->smarty->assign(array(
				'status' => $this->context->cookie->parent_group_saved,
				'type' => 'success',
			));
			$second_part_url = 'featuresgroup/views/templates/admin/status.tpl';
            $this->content .= $this->context->smarty->fetch(_PS_MODULE_DIR_.pSQL($second_part_url));
		}
		
        $this->content .= $this->renderForm();
        unset($this->context->cookie->error);
        unset($this->context->cookie->parent_group_saved);
        parent::initContent();
    }

    /**
     * Initialize Header Toolbar
     */
    public function initToolbar()
    {
        parent::initToolbar();
        $this->page_header_toolbar_btn['back_to_list'] = array(
            'href' => $this->context->link->getAdminLink('AdminProductsListing'),
            'desc' => $this->l('List Product Copies'),
            'icon' => 'process-icon-back',
        );
    }

    /**
     * Create the form that will be displayed in the controller page of your module.
     */
    public function renderForm()
    {
        $this->fields_form = array(
            'legend' => array(
                'title' => $this->l('Create Parent Group'),
                'icon' => 'icon-user',
            ),
            'input' => array(
                array(
                    'col' => 3,
                    'type' => 'text',
                    'label' => $this->l('Enter Parent Group Name'),
                    'name' => 'FEATURESGROUP_PARENT_GROUP',
                    'required' => true,
                    'hint' => $this->l('Enter Parent Group Name.'),
                    'desc' => $this->l('Enter Parent Group Name'),
                    'form_group_class' => 'featuresgroup',
                ),
            ),
            'submit' => array(
                'title' => $this->l('Save'),
                'name' => 'submitFeaturesGroupParent',
            ),
        );

        $this->fields_value = array(
            'FEATURESGROUP_PARENT_GROUP' => Tools::getValue('FEATURESGROUP_PARENT_GROUP'),
        );

        return parent::renderForm();
    }

    /**
     * validate form data
     */
    protected function postValidation()
    {
        if (Tools::isSubmit('submitFeaturesGroupParent')) {
            if (!Tools::getValue('FEATURESGROUP_PARENT_GROUP')) {
                $this->postErrors[] = $this->l('Please Enter Parent Group Name.');
            }
        }
    }

    /**
     * Check form value Int of Not
     */
    public function isInt($value)
    {
        return ((string)(int)$value === (string)$value or $value === false);
    }

    /**
     * Check form Value Float Or Not
     */
    public function isFloat($float)
    {
        return ((string)(float)$float == (string)$float);
    }

    /**
     * Display form Errors
     */
    public function displayError($err)
    {
        $this->errors[] = $err;
    }

    /**
     * Process form Data
     */
    public function postProcess()
    {
        if (Tools::isSubmit('submitFeaturesGroupParent')) {
            $this->postValidation();
            if (!count($this->postErrors)) {
				Db::getInstance()->insert('parentfeatures', array(
                    'parent_group_name' => pSQL(Tools::getValue('FEATURESGROUP_PARENT_GROUP')),
                ));
                $this->context->cookie->__set('parent_group_saved', 'Parent Group Name Saved Successfully');
				Tools::redirectAdmin(self::$currentIndex . '&token=' . Tools::getAdminTokenLite('AdminFeaturesGroupAdd'));
				parent::postProcess();
            } else {
				$this->context->cookie->__set('error', 'Please Enter Parent Group Name');
				Tools::redirectAdmin(self::$currentIndex . '&token=' . Tools::getAdminTokenLite('AdminFeaturesGroupAdd'));
				parent::postProcess();
			}
            
        }
    }
}
