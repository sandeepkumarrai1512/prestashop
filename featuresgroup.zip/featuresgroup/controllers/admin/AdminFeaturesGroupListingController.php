<?php
/**
* 2007-2019 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author    PrestaShop SA <contact@prestashop.com>
*  @copyright 2007-2019 PrestaShop SA
*  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

require_once _PS_MODULE_DIR_.'featuresgroup/classes/FeaturesGroupListing.php';
class AdminFeaturesGroupListingController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap = true;
        $this->table = 'featuresgroup';
        $this->className = 'FeaturesGroupListing';
        $this->identifier = 'id_featuresgroup';
        parent::__construct();
        $this->toolbar_title = $this->l('Manage All Features Group');
        $this->allow_export = true;

        $this->fields_list = array(
            'id_featuresgroup' => array(
                'title' => $this->l('ID'),
                'align' => 'center',
                'class' => 'fixed-width-xs',
                'remove_onclick' => true,
            ),
            'id_parent_feature_group' => array(
                'title' => $this->l('Parent Group'),
                'width' => '100',
                'remove_onclick' => true,
                'callback' => 'displayParentFeature' //will allow you to display the value in a custom way using a controller callback
            ),
            'features' => array(
                'title' => $this->l('Assigned Features'),
                'width' => '100',
                'remove_onclick' => true,
                'callback' => 'displayFeatures' //will allow you to display the value in a custom way using a controller callback
            ),
        );
        $this->bulk_actions = array(
            'delete' => array('text' => $this->l('Delete selected'),
                'icon' => 'icon-trash',
                'confirm' => $this->l('Delete selected Group?'),
            ),
        );
    }

    /**
     * Initialize Results Action
     */
    public function renderList()
    {
        $this->addRowAction('delete');
        return parent::renderList();
    }

    public function displayFeatures($features) {
		$explode_features = explode(',', $features);
		$features_name = array();
		foreach ($explode_features as $single) {
			$sql = 'select name from `' . _DB_PREFIX_ . 'feature_lang` where id_feature="'.$single.'" AND id_lang="'.$this->context->language->id.'"';
		    $feature_name = Db::getInstance()->getValue($sql);
		    $features_name[] = $feature_name;
		}
        return implode(', ',$features_name);
    }
    
    public function displayParentFeature($id_parent_feature_group) {
		$sql = 'select parent_group_name from `' . _DB_PREFIX_ . 'parentfeatures` where id_parentfeatures="'.$id_parent_feature_group.'"';
		$parent_feature_name = Db::getInstance()->getValue($sql);
        return $parent_feature_name;
    }
}
