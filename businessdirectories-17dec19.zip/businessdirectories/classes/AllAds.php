<?php
/**
* 2010-2018 Webkul.
*
* NOTICE OF LICENSE
*
* All right is reserved,
* Please go through this link for complete license : https://store.webkul.com/license.html
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade this module to newer
* versions in the future. If you wish to customize this module for your
* needs please refer to https://store.webkul.com/customisation-guidelines/ for more information.
*
*  @author    Webkul IN <support@webkul.com>
*  @copyright 2010-2018 Webkul IN
*  @license   https://store.webkul.com/license.html
*/

class AllAds extends ObjectModel
{
    public $id_customer;
    public $id_shop;
    public $title;
    public $description;
    public $purchase_type;
    public $price_start;
    public $price_end;
    public $show_text;
    public $expire_date;
    public $created_date;

    public static $definition = array(
        'table' => 'businessdirectories_ads',
        'primary' => 'id_ad',
        'fields' => array(
            'id_customer' => array('type' => self::TYPE_INT),
            'id_shop' => array('type' => self::TYPE_INT),
            'title' => array('type' => self::TYPE_STRING),
            'description' => array('type' => self::TYPE_STRING),
            'purchase_type' => array('type' => self::TYPE_STRING),
            'price_start' => array('type' => self::TYPE_STRING),
            'price_end' => array('type' => self::TYPE_STRING),
            'show_text' => array('type' => self::TYPE_STRING),
            'expire_date' => array('type' => self::TYPE_STRING),
            'created_date' => array('type' => self::TYPE_STRING),
        ),
    );

    public function delete()
    {
        $deleteAd = Db::getInstance()->execute(
            'DELETE FROM `'._DB_PREFIX_.'businessdirectories_ads`
            WHERE `id_ad` = '.(int) $this->id
        );

        if (!$deleteAd || !parent::delete()) {
            return false;
        }

        return true;
    }

    /**
     * Get payment modes created by admin for seller
     *
     * @return array
     */
    public static function getAds()
    {
        return Db::getInstance()->executeS('SELECT * FROM `'._DB_PREFIX_.'businessdirectories_ads`');
    }

    public static function getallTags()
    {
        return Db::getInstance()->executeS('SELECT id_tag, name as tags FROM `'._DB_PREFIX_.'businessdirectories_tags` ORDER BY `id_tag` DESC ');
    }

    public static function getImages($id_ad)
    {

        $imgid = Db::getInstance()->executeS('SELECT * FROM `ps_businessdirectories_ad_images` WHERE `id_ad` = '.$id_ad.'  GROUP by id_ad ORDER BY `id_image` DESC');
        return $imgid;

    }
    public static function getImagesName($id_ad)
    {
        $imgName = Db::getInstance()->executeS('SELECT name  FROM `'._DB_PREFIX_.'businessdirectories_images` WHERE `id_image` = "'.$id_ad.'" ');
        return $imgName;

    }
    
    public function listallads( $offset, $limit)
    {
        //return Db::getInstance()->executeS('SELECT * FROM `'._DB_PREFIX_.'businessdirectories_ads` ORDER BY id_ad DESC LIMIT '.$offset.','.$limit);
       
         return Db::getInstance()->executeS('SELECT ps_customer.firstname, ps_customer.lastname, ps_businessdirectories_ads.* FROM `ps_customer` inner join ps_businessdirectories_ads on ps_businessdirectories_ads.id_customer = ps_customer.id_customer ORDER BY ps_businessdirectories_ads.id_ad DESC LIMIT '.$offset.','.$limit);

        
    }

    public function alladsid()
    {
        return Db::getInstance()->executeS('SELECT  id_ad FROM `'._DB_PREFIX_.'businessdirectories_ads` ORDER BY id_ad DESC');
        
    }
    
    public function countads()
    {
        return Db::getInstance()->getRow('SELECT count(*) as total_ads FROM `'._DB_PREFIX_.'businessdirectories_ads` ');
    }
    
    public function currentUserAd($id_customer, $ad_id)
    {
        return Db::getInstance()->getRow('SELECT * FROM `'._DB_PREFIX_.'businessdirectories_ads` where id_customer="'.(int)$id_customer.'" AND id_ad="'.$ad_id.'"');
    }
    
    public function getAd($id_ad)
    {
        return Db::getInstance()->getRow('SELECT * FROM `'._DB_PREFIX_.'businessdirectories_ads` where id_ad="'.$id_ad.'"');
    }
}
