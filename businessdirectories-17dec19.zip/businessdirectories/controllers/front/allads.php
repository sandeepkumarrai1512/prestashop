<?php
/**
* 2007-2019 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author    PrestaShop SA <contact@prestashop.com>
*  @copyright 2007-2019 PrestaShop SA
*  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

require_once(_PS_MODULE_DIR_ . 'businessdirectories/classes/AllAds.php');
class BusinessdirectoriesAllAdsModuleFrontController extends ModuleFrontControllerCore
{
    public function init()
    {
        $this->page_name = 'All Ads';
        $this->disableBlocks();
        parent::init();


    }

    protected function disableBlocks()
    {
        $this->display_column_left = false;
    }

    public function initContent()
    {
        parent::initContent();

         


        $base_url = Tools::getHttpHost(true).__PS_BASE_URI__;

        if ( isset($_POST['searchAd'])  )  {

            $base_url = Tools::getHttpHost(true).__PS_BASE_URI__;

            /*echo "<pre>";
            print_r($_POST);*/

            $adtitle = $_POST['title'];

            $tagres = implode(',', $_POST['tags'] );

            $getallTags1 = Db::getInstance()->executeS('SELECT id_tag, name as tags FROM `'._DB_PREFIX_.'businessdirectories_tags` ORDER BY `id_tag` DESC ');

            

            $sqltag = "SELECT * FROM `ps_businessdirectories_ad_tags` WHERE `id_tag` IN (".$tagres.") ORDER BY `id_tag` ASC";

            $titleres = Db::getInstance()->executeS( $sqltag );

            $adsid = array();

            foreach($titleres as $titleres1 ){
            $adsid = $titleres1['id_ad'];

            }            

            $selads = "SELECT *  FROM `ps_businessdirectories_ads` WHERE `id_ad` IN ($adsid)";

            $selads .= "OR `title` LIKE '%$adtitle%'";


            $adsresults = Db::getInstance()->executeS( $selads );

            $countads = "SELECT count(*) as total_ads FROM `ps_businessdirectories_ads` WHERE `id_ad` IN ($adsid)";
            $countads .= "OR `title` LIKE '%$adtitle%'";


            $total_pagescount = Db::getInstance()->getValue( $countads );

            
            
           $getimgName = '1360118267new-slider.jpg';

            $limit = 10;
            $page_no = (!empty(Tools::getValue('page_no'))) ? Tools::getValue('page_no') : 1;
            $offset = ($page_no-1) * $limit;

            $total_pages = ceil( $total_pagescount / $limit);

           //$total_pages =  Db::getInstance()->getRow('SELECT count(*) as total_ads FROM `'._DB_PREFIX_.'businessdirectories_ads` ');



             $this->context->smarty->assign(array(
                'list_ads' => $adsresults,
                'base_url' => $base_url,
                'getalltags' => $getallTags1,
                'page_no' => $page_no,
                'getimages' => $getimgName,
                'total_pages' => $total_pages
            ) );

            

             

            if (Businessdirectories::isPs17()) {
                return $this->setTemplate('module:businessdirectories/views/templates/front/search-ads.tpl');
                //$this->setTemplate('module:businessdirectories/views/templates/front/search-ads.tpl');
                
            } else {
                die('no temp..');
                //$this->setTemplate('module:businessdirectories/views/templates/front/all-ads.tpl');
            }
            
            

            
        }

        
			$object = new AllAds();
           
			$limit = 10;
			$page_no = (!empty(Tools::getValue('page_no'))) ? Tools::getValue('page_no') : 1;
			$offset = ($page_no-1) * $limit;
            $total_ads = $object->countads();
            $total_pages = ceil($total_ads['total_ads'] / $limit);

            $all_ads = $object->listallads( $offset, $limit);
            /*echo "<pre>";
            print_r($all_ads);
            die('hi..');*/

            $getallTags = $object->getallTags( $offset, $limit);

            $alladsid = $object->alladsid();

            $getImages = array(); 
            $imgId = array();
            $getimgName = array();

            

            $imgId = array();

            foreach ($alladsid as $getid ) {
            
            $imgId[] =   $getid['id_ad'];
        }

         //echo '<pre>'; print_r($imgId); 

        $getImgresult = array();

        foreach($imgId as $imgId1 ){

            $getImgresult[$imgId1] = $object->getImages($imgId1); 

        }

        /*echo '<pre>'; print_r($getImgresult); 
         echo '<pre>'; print_r($all_ads); */

         $alladsimgdata=array();
         foreach($all_ads as $ads_key => $ads_val) {

            foreach($getImgresult as $imgkey => $imgval) {

                 if($imgkey == $ads_val['id_ad']) {
                    $alladsimgdata[$ads_key]   = $ads_val;
                    $alladsimgdata[$ads_key]['image_data'] = $imgval;
                     //$alladsimgdata[$ads_key]   = $ads_val;
                 }

            }


         }

        /* echo 'SELECT name  FROM `'._DB_PREFIX_.'businessdirectories_images` WHERE `id_image` = 3';
         die('exit..');*/

         $getimgName = array();

        foreach($alladsimgdata as $getImgInfo ) {
        foreach($getImgInfo['image_data'] as $imgifo ) {
        foreach ($imgifo as $singleid ){
        //print_r($singleid);
        $getimgresult = $object->getImagesName( $singleid ); 
        foreach($getimgresult as $getimgresult ) {
        $getimgName = $getimgresult['name'];
    }

    }

    }
    }

   /* echo "<br/><pre>";
    print_r($alladsimgdata);
    exit();*/


         //echo 'updated ads data<pre>'; print_r($alladsimgdata); 

        //exit;

       /* $getImgInfo = array();

        foreach($getImgresult as $getImgresult) {
        $getImgInfo['id_image'] =  $getImgresult['id_image'];
        //$getImgInfo['id_ad'] =  $getImgresult['id_ad'];
        }*/



        /*$imgId = array();

        foreach($getImgInfo as $getImgInfo ){            
        $imgId = $getImgInfo['id_image'];

         }*/

         /*print_r($getImgInfo);
         die('ji..');*/
         //$getimgres = array();

        

    /*echo "<pre>";
    print_r($getimgresult);
    die('ssl..');*/
         

        //$getimgName = array();
        /*foreach ($getimgresult as $getimgres) {
        
        $getimgName = $getimgres['name'];
        }*/
        /*echo "imagname:<pre> ";
        print_r($getimgName);
        die('hi..');*/

            $this->context->smarty->assign(array(
                'list_ads' => $all_ads,
                'base_url' => $base_url,
                'getalltags' => $getallTags,
                'page_no' => $page_no,
                'getimages' => $getimgName,
                'total_pages' => $total_pages
            ));
            if (Businessdirectories::isPs17()) {
                $this->setTemplate('module:businessdirectories/views/templates/front/all-ads.tpl');
            } else {
                $this->setTemplate('list-my-ads-1-6.tpl');
            }
            
            /*if (!empty(Tools::getValue('type'))) {
				Db::getInstance()->delete('businessdirectories_ads', 'id_ad = '.(int)Tools::getValue('id_ad'));
				Db::getInstance()->delete('businessdirectories_ad_types', 'id_ad = '.(int)Tools::getValue('id_ad'));
				Db::getInstance()->delete('businessdirectories_ad_tags', 'id_ad = '.(int)Tools::getValue('id_ad'));
				Db::getInstance()->delete('businessdirectories_ad_images', 'id_ad = '.(int)Tools::getValue('id_ad'));
                $this->context->smarty->assign(array(
                    'success' => 'Ad Successfully deleted',
                ));

                Tools::redirect($base_url.'allads');
            }*/
        
    }
    
    /**
     * @return array
     */
    public function getBreadcrumbLinks()
    {
        $breadcrumb = parent::getBreadcrumbLinks();
        $breadcrumb['links'][] = $this->addMyAccountToBreadcrumb();

        return $breadcrumb;
    }
}
