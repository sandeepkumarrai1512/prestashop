<?php
/**
* 2010-2018 Webkul.
*
* NOTICE OF LICENSE
*
* All right is reserved,
* Please go through this link for complete license : https://store.webkul.com/license.html
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade this module to newer
* versions in the future. If you wish to customize this module for your
* needs please refer to https://store.webkul.com/customisation-guidelines/ for more information.
*
*  @author    Webkul IN <support@webkul.com>
*  @copyright 2010-2018 Webkul IN
*  @license   https://store.webkul.com/license.html
*/

class AllAds extends ObjectModel
{
    public $id_customer;
    public $id_shop;
    public $title;
    public $description;
    public $purchase_type;
    public $price_start;
    public $price_end;
    public $show_text;
    public $expire_date;
    public $created_date;

    public static $definition = array(
        'table' => 'businessdirectories_ads',
        'primary' => 'id_ad',
        'fields' => array(
            'id_customer' => array('type' => self::TYPE_INT),
            'id_shop' => array('type' => self::TYPE_INT),
            'title' => array('type' => self::TYPE_STRING),
            'description' => array('type' => self::TYPE_STRING),
            'purchase_type' => array('type' => self::TYPE_STRING),
            'price_start' => array('type' => self::TYPE_STRING),
            'price_end' => array('type' => self::TYPE_STRING),
            'show_text' => array('type' => self::TYPE_STRING),
            'expire_date' => array('type' => self::TYPE_STRING),
            'created_date' => array('type' => self::TYPE_STRING),
        ),
    );

    public function delete()
    {
        $deleteAd = Db::getInstance()->execute(
            'DELETE FROM `'._DB_PREFIX_.'businessdirectories_ads`
            WHERE `id_ad` = '.(int) $this->id
        );

        if (!$deleteAd || !parent::delete()) {
            return false;
        }

        return true;
    }

    /**
     * Get payment modes created by admin for seller
     *
     * @return array
     */
    public static function getAds()
    {
        return Db::getInstance()->executeS('SELECT * FROM `'._DB_PREFIX_.'businessdirectories_ads`');
    }

    public static function getallTags()
    {
        return Db::getInstance()->executeS('SELECT id_tag, name as tags FROM `'._DB_PREFIX_.'businessdirectories_tags` ORDER BY `id_tag` DESC ');
    }

    public static function getadsType()
    {
        return Db::getInstance()->executeS('SELECT name, id_type FROM `'._DB_PREFIX_.'businessdirectories_types` ORDER BY `id_type` DESC');
    }

    /*public static function getImages($id_ad)
    {  
        $ad_images = Db::getInstance()->executeS('SELECT bi.`name` FROM `'._DB_PREFIX_.'businessdirectories_ad_images` as bai INNER JOIN `'._DB_PREFIX_.'businessdirectories_images` as bi ON (bi.id_image=bai.id_image) WHERE bai.`id_ad` = '.$id_ad.' AND bi.`type` < 1');
        $images = array();
        foreach ($ad_images as $image) {
            $images[] = $image['name'];
        }
        return $images;

    }*/

    public static function getImages($id_ad)
    {  
        $ad_images = Db::getInstance()->executeS('SELECT bi.`name` FROM `'._DB_PREFIX_.'businessdirectories_ad_images` as bai INNER JOIN `'._DB_PREFIX_.'businessdirectories_images` as bi ON (bi.id_image=bai.id_image) WHERE bai.`id_ad` = '.$id_ad.' AND bi.`type` < 1');


    $ad_video = Db::getInstance()->executeS('SELECT bi.`name` FROM `'._DB_PREFIX_.'businessdirectories_ad_images` as bai INNER JOIN `'._DB_PREFIX_.'businessdirectories_images` as bi ON (bi.id_image=bai.id_image) WHERE bai.`id_ad` = '.$id_ad.' AND bi.`type` = 1');

     
    
        $images = array();
    
    if(!empty($ad_images)) {
        foreach ($ad_images as $image) {
            $images['image'] = $image['name'];
        }
    } elseif($ad_video) {
        foreach ($ad_video as $advideo) {
            $images['video'] = $advideo['name']; 
        }
    } else {
      $images='';
    }
        return $images;

    }


    public static function getVideos($id_ad)
    {  
        $ad_videos = Db::getInstance()->executeS('SELECT bi.`name` FROM `'._DB_PREFIX_.'businessdirectories_ad_images` as bai INNER JOIN `'._DB_PREFIX_.'businessdirectories_images` as bi ON (bi.id_image=bai.id_image) WHERE bai.`id_ad` = '.$id_ad.' AND bi.`type` = 1');
        $videos = array();
        foreach ($ad_videos as $video) {
            $videos[] = $video['name'];
        }
        return $videos;

    }
    public static function getImagesName($id_ad)
    {
        $imgName = Db::getInstance()->executeS('SELECT name  FROM `'._DB_PREFIX_.'businessdirectories_images` WHERE `id_image` = "'.$id_ad.'" ');
        return $imgName;

    }
    
    public function listallads( $offset, $limit)
    {
        return Db::getInstance()->executeS('SELECT c.`firstname`, c.`lastname`, ba.* FROM `'._DB_PREFIX_.'businessdirectories_ads` as ba inner join `'._DB_PREFIX_.'customer` as c on ba.id_customer = c.id_customer ORDER BY ba.id_ad DESC LIMIT '.$offset.','.$limit);
    }
    
    public function countads()
    {
        return Db::getInstance()->getRow('SELECT count(*) as total_ads FROM `'._DB_PREFIX_.'businessdirectories_ads` ');
    }
    
    public function currentUserAd($id_customer, $ad_id)
    {
        return Db::getInstance()->getRow('SELECT * FROM `'._DB_PREFIX_.'businessdirectories_ads` where id_customer="'.(int)$id_customer.'" AND id_ad="'.$ad_id.'"');
    }
    
    public function getAd($id_ad)
    {
        return Db::getInstance()->getRow('SELECT * FROM `'._DB_PREFIX_.'businessdirectories_ads` where id_ad="'.$id_ad.'"');
    }
}
