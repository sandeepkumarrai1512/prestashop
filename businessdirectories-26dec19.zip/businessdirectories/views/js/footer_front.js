$(window).load(function() {
   alert('test 1.....');
 // The slider being synced must be initialized first
/* $('#carousel').flexslider({
   animation: "slide",
   controlNav: false,
   animationLoop: false,
   slideshow: false,
   itemWidth: 210,
   itemMargin: 5,
   asNavFor: '#slider'
 });*/

  $('#carousel').flexslider();
alert('test 3.....');

 /*$('#slider').flexslider({
   animation: "slide",
   controlNav: false,
   animationLoop: false,
   slideshow: false,
   sync: "#carousel"
 });
});*/
$('#slider').flexslider();
alert('test 2.....');