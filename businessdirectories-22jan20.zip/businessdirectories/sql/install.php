<?php
/**
* 2007-2019 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author    PrestaShop SA <contact@prestashop.com>
*  @copyright 2007-2019 PrestaShop SA
*  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/
$sql = array();

$sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'businessdirectories` (
    `id_businessdirectories` int(11) NOT NULL AUTO_INCREMENT,
    PRIMARY KEY  (`id_businessdirectories`)
) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8;';

$sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'businessdirectories_types` (
    `id_type` int(11) NOT NULL AUTO_INCREMENT,
    `name` varchar(255) NOT NULL,
    `date_add` date NOT NULL,
    PRIMARY KEY  (`id_type`)
) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8;';

$sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'businessdirectories_tags` (
    `id_tag` int(11) NOT NULL AUTO_INCREMENT,
    `name` varchar(255) NOT NULL,
    `date_add` date NOT NULL,
    PRIMARY KEY  (`id_tag`)
) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8;';

$sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'businessdirectories_images` (
    `id_image` int(11) NOT NULL AUTO_INCREMENT,
    `id_customer` int(11) NOT NULL,
    `name` varchar(255) NOT NULL,
    `type` INT NOT NULL,
    `date_add` date NOT NULL,
    PRIMARY KEY  (`id_image`)
) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8;';

$sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'businessdirectories_ads` (
    `id_ad` int(11) NOT NULL AUTO_INCREMENT,
    `id_customer` int(11) NOT NULL,
    `id_shop` int(11) NOT NULL,
    `title` TEXT NOT NULL,
    `description` TEXT NOT NULL,
    `purchase_type` varchar(255) NOT NULL,       
    `currency_type` int(11) NOT NULL,
    `price_start` varchar(255) NOT NULL,
    `price_end` varchar(255) NOT NULL,
    `show_text` TEXT DEFAULT NULL,
    `expire_date` date DEFAULT NULL,
    `never_expire` VARCHAR(255) NOT NULL,
    `information_width` VARCHAR(255) NOT NULL,
    `information_height` VARCHAR(255) NOT NULL,
    `information_depth` VARCHAR(255) NOT NULL,
    `information_built` VARCHAR(255) NOT NULL,
    `information_package` VARCHAR(255) NOT NULL,
    `information_assembly` VARCHAR(255) NOT NULL,
    `information_flysys` VARCHAR(255) NOT NULL,
    `information_linesets` VARCHAR(255) NOT NULL,
    `information_softdrops` VARCHAR(255) NOT NULL,
    `information_dropwidth` VARCHAR(255) NOT NULL,
    `information_dropxwidth` VARCHAR(255) NOT NULL,
    `information_trucks` VARCHAR(255) NOT NULL,
    `information_trucksizes` VARCHAR(255) NOT NULL,
    `information_trailer_stay` VARCHAR(255) NOT NULL,

    `includes_rigging` VARCHAR(255) NOT NULL,
    `includes_hardware` VARCHAR(255) NOT NULL,
    `includes_tools` VARCHAR(255) NOT NULL,
    `manpower_need` VARCHAR(255) NOT NULL,
    `manpower_install` VARCHAR(255) NOT NULL,
    `manpower_crew` VARCHAR(255) NOT NULL,

    `inventry_scenery_items` TEXT NOT NULL,
    `inventry_scenery_desc` TEXT NOT NULL,
    `inventry_props_items` TEXT NOT NULL,
    `inventry_props_desc` TEXT NOT NULL,
    `inventry_dress_items` TEXT NOT NULL,
    `inventry_dress_desc` TEXT NOT NULL,
    
    `tech_built` VARCHAR(255) NOT NULL,
    `tech_setsize` VARCHAR(255) NOT NULL,
    `tech_wing` VARCHAR(255) NOT NULL,

    `tech_minstage` VARCHAR(255) NOT NULL,
    `tech_maxstage` VARCHAR(255) NOT NULL,

    `tech_description` TEXT NOT NULL,

    `tech_people` VARCHAR(255) NOT NULL,
    `tech_cock` VARCHAR(255) NOT NULL,
    `tech_packs` VARCHAR(255) NOT NULL,
    `tech_unholds` VARCHAR(255) NOT NULL,
    `techunload_description` TEXT NOT NULL,
    `tech_trucks` VARCHAR(255) NOT NULL,    
    `rigging_ups` VARCHAR(255) NOT NULL,
    `rigging_downs` VARCHAR(255) NOT NULL,
    `rigging_lines` VARCHAR(255) NOT NULL,

    `rigging_header` VARCHAR(255) NOT NULL,
    `rigging_portals` VARCHAR(255) NOT NULL,
    `rigging_description` TEXT NOT NULL,
    `assembly_crew` VARCHAR(255) NOT NULL,
    `assembly_esthours` VARCHAR(255) NOT NULL,
    `assembly_tools` VARCHAR(255) NOT NULL,
    `assembly_connections` VARCHAR(255) NOT NULL,
    `assembly_description` TEXT NOT NULL,
    `run_desckcrew` VARCHAR(255) NOT NULL,
    `run_flymen` VARCHAR(255) NOT NULL,
    `run_actors` VARCHAR(255) NOT NULL,
    `run_softdrops` VARCHAR(255) NOT NULL,
    `run_waggons` VARCHAR(255) NOT NULL,
    `run_description` TEXT NOT NULL,
    `loading_esthours` VARCHAR(255) NOT NULL,
    `loading_docks` VARCHAR(255) NOT NULL,
    `loading_loadreq` VARCHAR(255) NOT NULL,
    `loading_strap` VARCHAR(255) NOT NULL,
    `loading_crewreq` VARCHAR(255) NOT NULL,
    `loading_description` TEXT NOT NULL,

    `created_date` date NOT NULL,
    PRIMARY KEY  (`id_ad`)
) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8;';

$sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'businessdirectories_shipping` (
    `id_shipping` int(11) NOT NULL AUTO_INCREMENT,
    `name` varchar(255) NOT NULL,
    `date_add` date NOT NULL,
    PRIMARY KEY  (`id_shipping`)
) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8;';

$sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'businessdirectories_ad_shipping` (
    `id_ad_shipping` int(11) NOT NULL AUTO_INCREMENT,
    `id_ad` int(11) NOT NULL,
    `id_shipping` int(11) NOT NULL,
    PRIMARY KEY  (`id_ad_shipping`)
) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8;';

$sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'businessdirectories_ad_types` (
    `id_ad_type` int(11) NOT NULL AUTO_INCREMENT,
    `id_ad` int(11) NOT NULL,
    `id_type` int(11) NOT NULL,
    PRIMARY KEY  (`id_ad_type`)
) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8;';

$sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'businessdirectories_ad_tags` (
    `id_ad_tag` int(11) NOT NULL AUTO_INCREMENT,
    `id_ad` int(11) NOT NULL,
    `id_tag` int(11) NOT NULL,
    PRIMARY KEY  (`id_ad_tag`)
) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8;';

$sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'businessdirectories_ad_images` (
    `id_ad_image` int(11) NOT NULL AUTO_INCREMENT,
    `id_ad` int(11) NOT NULL,
    `id_image` int(11) NOT NULL,
    PRIMARY KEY  (`id_ad_image`)
) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8;';

$sql[] = 'CREATE TABLE `' . _DB_PREFIX_ . 'rating` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `id_ad` int(11) NOT NULL,
 `rating_number` int(11) NOT NULL,
 `id_customer` int(11) NOT NULL,
 `user_ip` varchar(20) COLLATE utf8_unicode_ci NOT NULL COMMENT "User IP Address",
 `submitted` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;';


foreach ($sql as $query) {
    if (Db::getInstance()->execute($query) == false) {
        return false;
    }
}


Db::getInstance()->insert('businessdirectories_shipping', array(
    'name' => 'Entire USA',
    'date_add'      => date("Y-m-d"),
));
Db::getInstance()->insert('businessdirectories_shipping', array(
    'name' => 'Canada',
    'date_add'      => date("Y-m-d"),
));
Db::getInstance()->insert('businessdirectories_shipping', array(
    'name' => 'West Coast Only',
    'date_add'      => date("Y-m-d"),
));
Db::getInstance()->insert('businessdirectories_shipping', array(
    'name' => 'East Coast Only',
    'date_add'      => date("Y-m-d"),
));
Db::getInstance()->insert('businessdirectories_shipping', array(
    'name' => 'Central United States Only',
    'date_add'      => date("Y-m-d"),
));
Db::getInstance()->insert('businessdirectories_shipping', array(
    'name' => 'Canada Only',
    'date_add'      => date("Y-m-d"),
));


/* Create New Group */
$group_info = Db::getInstance()->getRow('SELECT id_group FROM `'._DB_PREFIX_.'group_lang` WHERE `name` = "Vendor"');
if (empty($group_info)) {
    $group = new Group();
    $group->name = array(Configuration::get('PS_LANG_DEFAULT') => 'Vendor');
    $group->price_display_method = 1;
    $group->add();
}