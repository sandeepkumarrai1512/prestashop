<?php
/**
* 2007-2019 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author    PrestaShop SA <contact@prestashop.com>
*  @copyright 2007-2019 PrestaShop SA
*  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/
require_once(_PS_MODULE_DIR_ . 'businessdirectories/classes/AdsListing.php');
require_once(_PS_MODULE_DIR_ . 'businessdirectories/classes/TypesListing.php');
class BusinessdirectoriesEditAdModuleFrontController extends ModuleFrontControllerCore
{
    public function init()
    {
        $this->page_name = 'Edit Ad';
        $this->disableBlocks();
        parent::init();
    }
    protected function disableBlocks()
    {
        $this->display_column_left = false;
    }
    public function initContent()
    {   
        parent::initContent();
        $base_url = Tools::getHttpHost(true).__PS_BASE_URI__;

    if (!$this->context->customer->isLogged() && $this->php_self != 'authentication' && $this->php_self != 'password') {
            Tools::redirect('index.php?controller=authentication?back=my-account');
        } else {

    if (!empty(Tools::getValue('delid'))) {

    $sql =   Db::getInstance()->getRow('SELECT name FROM `'._DB_PREFIX_.'businessdirectories_images` where id_image="'.Tools::getValue('delid').'" ');
    $target_dir = _PS_MODULE_DIR_."businessdirectories/uploads/";

    if (file_exists($target_dir.$sql['name'])) 
    {
    unlink($target_dir.$sql['name']);
    echo "File Successfully Delete."; 
    

    $return_arr = array(); 
    Db::getInstance()->delete('businessdirectories_images', 'id_image = '.Tools::getValue('delid') );
    Db::getInstance()->delete('businessdirectories_ad_images', 'id_image = '.Tools::getValue('delid')
        );

    $return_arr = array(
        "msg" => 'success',
        "status" => 1
        );
    }else{
    echo "File does not exists"; 
    }

    echo json_encode($return_arr);
    }

    


    if (!empty($_FILES)) {
        
        $filetypeval = '';
                // Count total files
        //$countfiles = count($_FILES['images']['name']);

        $fileSizes = '';
        //$id_ad = Tools::getValue('id_ad');
       
        
        // Looping all files
     //for($i=0;$i<$countfiles;$i++){ 

        $target_dir = _PS_MODULE_DIR_."businessdirectories/uploads/";
                    $file_name = str_replace(" ","",basename( $_FILES['images']['name'] ) );

                    
                                       
                    if(!empty($file_name )){ 
                    $return_arr = array();

                    $file_name1 = rand().$file_name;

                    $target_file = $target_dir . $file_name1;

                    $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
                    
                    if( $imageFileType == "mp4" || $imageFileType == "webm" || $imageFileType == "wav" )
                    {
                        
                        $filetypeval = 1;
                    }else{
                      
                        $filetypeval = 0;  
                    } 

                    if( $_FILES['images']['size'] > 104857600 ){
                    
                    $return_arr = array("id" => $image_id,
                    "type" => $filetypeval,

                    "msg" => 'Sorry, your file is too large. You can upload files upto 100MB',
                    "status" => 0
                    );
                        

                        }else{

 $fileupload = move_uploaded_file( $_FILES['images']['tmp_name'], $target_file);
 if($fileupload){
                        
                    $add_new_img = Db::getInstance()->insert('businessdirectories_images', array(
                        'id_customer' => (int)$this->context->customer->id,
                        'name' => $file_name1,
                        'type' => $filetypeval,
                        'date_add' => date('Y-m-d')
                    ));

                    $image_id = Db::getInstance()->Insert_ID();
                    Db::getInstance()->insert('businessdirectories_ad_images', array(
                        'id_ad' => Tools::getValue('id_ad'),
                        'id_image' => (int)$image_id
                    ));

                    $return_arr = array("id" => $image_id,
                    "type" => $filetypeval,
                    "msg" => 'File uploaded successfully.',
                    "imgsrc" => $file_name1,
                    "status" => 1
                    );
        }else{

        $return_arr = array( 
                    "id" => $image_id,
                    "type" => $filetypeval,
                    "msg" => 'Oops! Error in upload. Please try again.',
                    "status" => 0
                    ); 
        }

                }
                } 
                //} 
                // Encoding array in JSON format
echo json_encode($return_arr);
                
            } 





        
        if (Tools::getValue('updateadd') == 'update' && !empty((int)Tools::getValue('id_ad'))) {
            if (Tools::getValue('never_expire')) {
                $never_expire = '1';
            } else {
                $never_expire = '';
            } 

            /*echo "<pre>";
            print_r($_POST);
            die('dsdsds');*/

            		 
            $id_customer = Tools::getValue('id_customer');
            $id_ad = Tools::getValue('id_ad');
            $title = Tools::getValue('title');
            $purchase_type = Tools::getValue('purchase_type');
            $price_start = Tools::getValue('price_start');
            $price_end = Tools::getValue('price_end');            
            $expire_date = Tools::getValue('expire_date');
            $never_expire = Tools::getValue('never_expire');
            $show_text = Tools::getValue('show_text');
            $description = Tools::getValue('description');
            
            // Delete Tag
            $deltags = 'DELETE FROM `'._DB_PREFIX_.'businessdirectories_ad_tags` WHERE `id_ad` = "'.$id_ad.'"';
            Db::getInstance()->execute($deltags);
            if (!empty(Tools::getValue('tags'))) {
                $explode_tags = explode(',', strtolower(trim(Tools::getValue('tags') ) ) );
                foreach ($explode_tags as $single_tag) {            
                    $checktag = Db::getInstance()->getRow('SELECT id_tag FROM `'._DB_PREFIX_.'businessdirectories_tags` where name="'.Tools::strtolower(trim($single_tag)).'"');
                    if (!empty($checktag)) {
                        $tag_id = $checktag['id_tag'];
                    } else {
                        $add_tag = Db::getInstance()->insert('businessdirectories_tags', array(
                            'name' => Tools::strtolower(trim($single_tag)),
                            'date_add' => date('Y-m-d')
                        ));
                        $tag_id = Db::getInstance()->Insert_ID();
                    }
                    Db::getInstance()->insert('businessdirectories_ad_tags', array(
                        'id_ad' => (int)$id_ad,
                        'id_tag' => (int)$tag_id
                    ));
                }
            }

            // Gallery images
            if (!empty(Tools::getValue('existing_images'))) {
                $delimg = "DELETE FROM `"._DB_PREFIX_."businessdirectories_ad_images` WHERE `id_ad` = '".$id_ad."' ";
                $galleryimg = Db::getInstance()->execute( $delimg );
                $explode_images_ids = explode(',', Tools::getValue('existing_images'));
                foreach ($explode_images_ids as $single_id) {                    
                    Db::getInstance()->insert('businessdirectories_ad_images', array(
                        'id_ad' => (int)$id_ad,
                        'id_image' => (int)$single_id
                    ));
                }
                
            }

            

            // Types
            $deltype = "DELETE FROM `"._DB_PREFIX_."businessdirectories_ad_types` WHERE `id_ad` = '".$id_ad."' ";
            $delres = Db::getInstance()->execute( $deltype );
            if (!empty(Tools::getValue('types'))) {
                foreach (Tools::getValue('types') as $single_type) {
                    $res = Db::getInstance()->insert('businessdirectories_ad_types', array(
                        'id_ad' => (int)$id_ad,
                        'id_type' => $single_type
                    ));
                }
            }


            //shipping
            $delshipping = "DELETE FROM `"._DB_PREFIX_."businessdirectories_ad_shipping` WHERE `id_ad` = '".$id_ad."' ";

            $delshipping_res = Db::getInstance()->execute( $delshipping );
            if (!empty(Tools::getValue('shipping_to'))) {
                foreach (Tools::getValue('shipping_to') as $single_shipping) {
                    
                    

                    $res1 = Db::getInstance()->insert('businessdirectories_ad_shipping', array(
                        'id_ad' => (int)$id_ad,
                        'id_shipping' => $single_shipping
                    ));
                }
            }

        if (!empty(Tools::getValue('hiddenimages'))) {
                $hiddenimages = explode(',', Tools::getValue('hiddenimages'));
                /*echo "<br/>hidden:<pre>";
                print_r($hiddenimages);*/
                foreach ($hiddenimages as $single_imgid) {
               
                
                Db::getInstance()->insert('businessdirectories_ad_images', array(
                        'id_ad' => Tools::getValue('id_ad'),
                        'id_image' => (int)$single_imgid
                    ));
                }
                
                

            }
            

            // Update ad information
            Db::getInstance()->update('businessdirectories_ads', array(
                
                'title' => pSQL(Tools::getValue('title')),
                'description' => pSQL(htmlentities(Tools::getValue('description'))),
                'purchase_type' => pSQl(Tools::getValue('purchase_type')), 
                'currency_type' => Tools::getValue('currency_type'),
                'price_start' => pSQL(Tools::getValue('price_start')),
                'price_end' => pSQL(Tools::getValue('price_end')),
                'show_text' => pSQL(Tools::getValue('show_text')),
                'expire_date' => pSQL(Tools::getValue('expire_date')),

                'information_width' => pSQL(Tools::getValue('information_width')),
                'information_height' => pSQL(Tools::getValue('information_height')),
                'information_depth' => pSQL(Tools::getValue('information_depth')),
                'information_built' => pSQL(Tools::getValue('information_built')),
                'information_package' => pSQL(Tools::getValue('information_package')),
                'information_assembly' => pSQL(Tools::getValue('information_assembly')),
                'information_flysys' => pSQL(Tools::getValue('information_flysys')),
                'information_linesets' => pSQL(Tools::getValue('information_linesets')),
                'information_softdrops' => pSQL(Tools::getValue('information_softdrops')),
                'information_dropwidth' => pSQL(Tools::getValue('information_dropwidth')),
                'information_dropxwidth' => pSQL(Tools::getValue('information_dropxwidth')),  
                'information_trucks' => pSQL(Tools::getValue('information_trucks')),
                'information_trucksizes' => pSQL(Tools::getValue('information_trucksizes')),
                'information_trailer_stay' => pSQL(Tools::getValue('information_trailer_stay')),

                'includes_rigging' => pSQL(Tools::getValue('includes_rigging')),
                'includes_hardware' => pSQL(Tools::getValue('includes_hardware')),
                'includes_tools' => pSQL(Tools::getValue('includes_tools')),
                'manpower_need' => pSQL(Tools::getValue('manpower_need')),
                'manpower_install' => pSQL(Tools::getValue('manpower_install')),
                'manpower_crew' => pSQL(Tools::getValue('manpower_crew')),

                'inventry_scenery_items' => serialize( Tools::getValue('inventry_scenery_items') ),
                'inventry_scenery_desc' => serialize( Tools::getValue('inventry_scenery_desc') ),
                'inventry_props_items' => serialize( Tools::getValue('inventry_props_items')),
                'inventry_props_desc' => serialize( Tools::getValue('inventry_props_desc')),
                'inventry_dress_items' => serialize( Tools::getValue('inventry_dress_items')),
                'inventry_dress_desc' => serialize( Tools::getValue('inventry_dress_desc') ),

                'tech_built' => pSQL(Tools::getValue('tech_built')),
                'tech_setsize' => pSQL(Tools::getValue('tech_setsize')),
                'tech_wing' => pSQL(Tools::getValue('tech_wing')),

                'tech_minstage' => pSQL(Tools::getValue('tech_minstage')),
                'tech_maxstage' => pSQL(Tools::getValue('tech_maxstage')),
                'tech_description' => pSQL(Tools::getValue('tech_description')),
                'tech_people' => pSQL(Tools::getValue('tech_people')),
                'tech_cock' => pSQL(Tools::getValue('tech_cock')),
                'tech_packs' => pSQL(Tools::getValue('tech_packs')),
                'tech_unholds' => pSQL(Tools::getValue('tech_unholds')),
                'tech_trucks' => pSQL(Tools::getValue('tech_trucks')),
                'techunload_description' => pSQL(Tools::getValue('techunload_description')),
                'rigging_ups' => pSQL(Tools::getValue('rigging_ups')),
                'rigging_downs' => pSQL(Tools::getValue('rigging_downs')),
                'rigging_lines' => pSQL(Tools::getValue('rigging_lines')),

                'rigging_header' => pSQL(Tools::getValue('rigging_header')),
                'rigging_portals' => pSQL(Tools::getValue('rigging_portals')),
                'rigging_description' => pSQL(Tools::getValue('rigging_description')),
                'assembly_crew' => pSQL(Tools::getValue('assembly_crew')),
                'assembly_esthours' => pSQL(Tools::getValue('assembly_esthours')),
                'assembly_tools' => pSQL(Tools::getValue('assembly_tools')),
                'assembly_connections' => pSQL(Tools::getValue('assembly_connections')),
                'assembly_description' => pSQL(Tools::getValue('assembly_description')),
                'run_desckcrew' => pSQL(Tools::getValue('run_desckcrew')),
                'run_flymen' => pSQL(Tools::getValue('run_flymen')),
                'run_actors' => pSQL(Tools::getValue('run_actors')),
                'run_softdrops' => pSQL(Tools::getValue('run_softdrops')),
                'run_waggons' => pSQL(Tools::getValue('run_waggons')),
                'run_description' => pSQL(Tools::getValue('run_description')),
                'loading_esthours' => pSQL(Tools::getValue('loading_esthours')),
                'loading_docks' => pSQL(Tools::getValue('loading_docks')),
                'loading_loadreq' => pSQL(Tools::getValue('loading_loadreq')),
                'loading_strap' => pSQL(Tools::getValue('loading_strap')),
                'loading_crewreq' => pSQL(Tools::getValue('loading_crewreq')),
                'loading_description' => pSQL(Tools::getValue('loading_description')),

                'never_expire' => pSQL(Tools::getValue('never_expire'))
                ), 'id_ad = '.(int)Tools::getValue('id_ad'));
         
            $this->context->smarty->assign(array(
                'success' => 'Ad Successfully updated',
            ));
            $redirect_url = $base_url."my-account/listads";
            $this->context->smarty->assign(array(
                'success' => 'Ad Successfully updated',
            ));
            $this->context->cookie->updatead = 'Ad Successfully updated';

           
            sleep(2);
            Tools::redirect($redirect_url);
            //header( "refresh:1;url= $redirect_url " );
        }
        if (!empty((int)Tools::getValue('id_ad'))) {
            $obj = new TypesListing();
            $object = new AdsListing();
            $base_url = Tools::getHttpHost(true).__PS_BASE_URI__;
            $get_ad = $object->getAd((int)Tools::getValue('id_ad'));

                        
            $id_ad = Tools::getValue('id_ad');
            $prices = array();
            $priceresult = Db::getInstance()->getRow('SELECT price_start, price_end FROM `'._DB_PREFIX_.'businessdirectories_ads` WHERE `id_ad` = "'.$id_ad.'"');
            foreach($priceresult as $resultprice ){
             $prices['price_start'] = $resultprice['price_start']; 
             $prices['price_end'] = $resultprice['price_end']; 
            }
            
            // get tags
            $get_ad_tags = $obj->getAdTags(Tools::getValue('id_ad'));
            if (!empty($get_ad_tags)) {
                $tags = array();
                foreach ($get_ad_tags as $single_tag) {
                    $tags[] = $single_tag['name'];
                }
                $ad_tags = implode(",", $tags);
            } else {
                $ad_tags = '';
            }
            // get types
            $get_ad_types = $obj->getAdvTypes(Tools::getValue('id_ad'));
            $adv_types = array();
            if (!empty($get_ad_types)) {
                foreach ($get_ad_types as $single_ad_type) { 
                   
                    $adv_types[$single_ad_type['id_type']] = $single_ad_type['name'];
                }
            }

             // get shippings
            $get_ad_shippings = $obj->getAdvShippings(Tools::getValue('id_ad'));
            $adv_shippings = array();
            if (!empty($get_ad_shippings)) {
                foreach ($get_ad_shippings as $single_ad_shipping) { 
                   
                    $adv_shippings[$single_ad_shipping['id_shipping']] = $single_ad_shipping['name'];
                }
            }


            $types = $obj->getAdTypes();
            $shippings = $obj->getAdShippings();
        
            // get images
            $images = $obj->getAllImages((int)$this->context->customer->id);

	    
	       $getAdvideos =$obj->getAdvideosByadsId(Tools::getValue('id_ad'));
            $get_ad_images = $obj->getAdvimages(Tools::getValue('id_ad'));
            
            $ad_images = array();
            if (!empty($get_ad_images)) {
                foreach ($get_ad_images as $single_ad_image) {
                    $ad_images[$single_ad_image['id_image']] = $single_ad_image['name'];
                }
            }




        $get_ad_singleimages = $obj->singleViewimages(Tools::getValue('id_ad'));
            
            $ad_singleimages = array();
            if (!empty($get_ad_singleimages)) {
                foreach ($get_ad_singleimages as $single_ad_image) {
                    $ad_singleimages[$single_ad_image['id_image']] = $single_ad_image['name'];
                }
            }

        

		if(!empty($ad_images)) { 
		 		
		 $excitimageids=implode(",",array_keys($ad_images));
		} else {
		 $excitimageids='';
		}

    $inventry_array = array();

    $scenery_desc = unserialize( $get_ad['inventry_scenery_desc']) ;
    $scenery_item = unserialize( $get_ad['inventry_scenery_items']) ;

    foreach ($scenery_item as $key => $val ){     
    $inventry_array['items'][] = $val;
    $inventry_array['desc'][] = $scenery_desc[$key];    
    }


    $props_array = array();

    $props_desc = unserialize( $get_ad['inventry_props_desc']) ;
    $props_item = unserialize( $get_ad['inventry_props_items']) ;

    foreach ($props_item as $key => $val ){     
    $props_array['items'][] = $val;
    $props_array['desc'][] = $props_desc[$key];    
    }

    $dressing_array = array();        
       
    $dressing_desc = unserialize( $get_ad['inventry_dress_desc']) ;
    $dressing_item = unserialize( $get_ad['inventry_dress_items']) ;

    foreach ($dressing_item as $key => $val ){     
    $dressing_array['items'][] = $val;
    $dressing_array['desc'][] = $dressing_desc[$key];    
    }

            $this->context->smarty->assign(array(
                'base_url' => $base_url,
                'get_ad' => $get_ad,
                'ad_tags' => $ad_tags,
                'adv_types' => $adv_types,
                'types'     => $types,
                'adv_shippings' => $adv_shippings,
                'shippings'     => $shippings,                
                'inventry_array' => $inventry_array,
                'props_array' => $props_array,
                'dressing_array' => $dressing_array,
                'images'    => $images,
		        'videos'    =>$getAdvideos,
                'prices' => $prices,
                'customer_id' => $this->context->customer->id,
                'ad_images' => $ad_images,
                'ad_singleimages' => $ad_singleimages, 
		        'exc_imageids' =>$excitimageids,
                'id_ad' => (int)Tools::getValue('id_ad')
            ));
            if (Businessdirectories::isPs17()) {
                $this->setTemplate('module:businessdirectories/views/templates/front/edit-my-ad.tpl');
            }
        } else {
            Tools::redirect('index.php');
        }
    }
    }
    
    /**
     * @return array
     */
    public function getBreadcrumbLinks()
    {
        $breadcrumb = parent::getBreadcrumbLinks();
        $breadcrumb['links'][] = $this->addMyAccountToBreadcrumb();
        if($this->context->customer->isLogged()){
        return $breadcrumb;
    }
    }
}
