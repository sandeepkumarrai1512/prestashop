<?php
/**
* 2007-2019 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author    PrestaShop SA <contact@prestashop.com>
*  @copyright 2007-2019 PrestaShop SA
*  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

require_once _PS_MODULE_DIR_.'businessdirectories/classes/AdsListing.php';
class AdminAdsListingController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap = true;
        $this->table = 'businessdirectories_ads';
        $this->className = 'AdsListing';
        $this->identifier = 'id_ad';
        parent::__construct();
        $this->toolbar_title = $this->l('Manage All Ads');

        $this->fields_list = array(
            'title' => array(
                'title' => $this->l('Title'),
                'align' => 'center',
                'class' => 'fixed-width-xs',
                'search' => true,
                'width' => 100,
                'remove_onclick' => true,
            ),
            'description' => array(
                'title' => $this->l('Description'),
                'width' => '100',
                'search' => true,
                'remove_onclick' => true,
                'callback' => 'displayDescription',
            ),
            'purchase_type' => array(
                'title' => $this->l('Purchase Type'),
                'width' => '100',
                'remove_onclick' => true,
                'search' => true
            ),
            'id_ad' => array(
                'title' => $this->l('Price Range'),
                'width' => '100',
                'search' => true,
                'remove_onclick' => true,
                'callback' => 'displayPriceRange'
            ),
            'show_text' => array(
                'title' => $this->l('Show'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'expire_date' => array(
                'title' => $this->l('Expiry Date'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'information_width' => array(
                'title' => $this->l('Information Width'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'information_height' => array(
                'title' => $this->l('Information Height'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'information_depth' => array(
                'title' => $this->l('Information Depth'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'information_built' => array(
                'title' => $this->l('Information Built'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'information_package' => array(
                'title' => $this->l('Information Package'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'information_assembly' => array(
                'title' => $this->l('Information Assembly'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'information_flysys' => array(
                'title' => $this->l('Information Flysys'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'information_linesets' => array(
                'title' => $this->l('information line sets'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'information_softdrops' => array(
                'title' => $this->l('information soft drops'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'information_dropwidth' => array(
                'title' => $this->l('information drop width'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'information_dropxwidth' => array(
                'title' => $this->l('X Width'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'information_trucks' => array(
                'title' => $this->l('information trucks'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'information_trucksizes' => array(
                'title' => $this->l('information truck sizes'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'information_trailer_stay' => array(
                'title' => $this->l('information trailer stay'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'includes_rigging' => array(
                'title' => $this->l('includes rigging'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'includes_hardware' => array(
                'title' => $this->l('includes hardware'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'includes_tools' => array(
                'title' => $this->l('includes tools'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'manpower_need' => array(
                'title' => $this->l('manpower need'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'manpower_install' => array(
                'title' => $this->l('manpower install'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'manpower_crew' => array(
                'title' => $this->l('manpower crew'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'inventry_scenery_items' => array(
                'title' => $this->l('inventry scenery items'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'inventry_scenery_desc' => array(
                'title' => $this->l('inventry scenery desc'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'inventry_props_items' => array(
                'title' => $this->l('inventry props items'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'inventry_props_desc' => array(
                'title' => $this->l('inventry props desc'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'inventry_dress_items' => array(
                'title' => $this->l('inventry dress items'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'inventry_dress_desc' => array(
                'title' => $this->l('inventry dress desc'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'tech_built' => array(
                'title' => $this->l('tech built'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'tech_setsize' => array(
                'title' => $this->l('tech setsize'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'tech_wing' => array(
                'title' => $this->l('tech wing'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'tech_minstage' => array(
                'title' => $this->l('tech min stage'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'tech_maxstage' => array(
                'title' => $this->l('tech max stage'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'tech_people' => array(
                'title' => $this->l('tech people'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'expire_date' => array(
                'title' => $this->l('Expiry Date'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'expire_date' => array(
                'title' => $this->l('Expiry Date'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'tech_cock' => array(
                'title' => $this->l('tech cock'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'tech_packs' => array(
                'title' => $this->l('tech packs'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'tech_unholds' => array(
                'title' => $this->l('tech unholds'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'tech_trucks' => array(
                'title' => $this->l('tech trucks'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'rigging_ups' => array(
                'title' => $this->l('rigging ups'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'rigging_downs' => array(
                'title' => $this->l('rigging downs'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'rigging_lines' => array(
                'title' => $this->l('rigging lines'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'rigging_header' => array(
                'title' => $this->l('rigging header'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'rigging_portals' => array(
                'title' => $this->l('rigging portals'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'assembly_crew' => array(
                'title' => $this->l('assembly crew'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'assembly_esthours' => array(
                'title' => $this->l('assembly est. hours'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'assembly_tools' => array(
                'title' => $this->l('assembly tools'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'assembly_connections' => array(
                'title' => $this->l('assembly connections'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'run_desckcrew' => array(
                'title' => $this->l('run desckcrew'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'run_flymen' => array(
                'title' => $this->l('run flymen'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'run_actors' => array(
                'title' => $this->l('run actors'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'run_softdrops' => array(
                'title' => $this->l('run soft drops'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'run_waggons' => array(
                'title' => $this->l('run waggons'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'loading_esthours' => array(
                'title' => $this->l('loading est hours'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'loading_docks' => array(
                'title' => $this->l('loading docks'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'loading_loadreq' => array(
                'title' => $this->l('loading load req'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'loading_strap' => array(
                'title' => $this->l('loading_strap'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'loading_crewreq' => array(
                'title' => $this->l('loading crewreq'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),


            'id_customer' => array(
                'title' => $this->l('Customer Name'),
                'width' => '100',
                'search' => true,
                'remove_onclick' => true,
                'callback' => 'displayCustomerName'
            ),
        );
        $this->bulk_actions = array(
            'delete' => array('text' => $this->l('Delete selected'),
                'icon' => 'icon-trash',
                'confirm' => $this->l('Delete selected Ad?'),
            ),
        );
    }

    /**
     * Initialize Header Toolbar
     */
    public function initToolbar()
    {
        parent::initToolbar();
    }

    /**
     * Initialize Results Action
     */
    public function renderList()
    {
        $this->addRowAction('delete');
        return parent::renderList();
    }
    
    public function displayPriceRange($id_ad) {
        $ad_info = Db::getInstance()->getRow('SELECT price_start, price_end FROM `'._DB_PREFIX_.'businessdirectories_ads` WHERE `id_ad` = "'.(int)$id_ad.'"');
        return Tools::displayPrice($ad_info['price_start']).' - '.Tools::displayPrice($ad_info['price_end']);
    }

    public function displayDescription($desc) {
        //$first10words = implode(' ', array_slice(str_word_count(html_entity_decode($desc),1), 0, 10));

       

    //return $first10words." ....";
        return html_entity_decode($desc);      
        //$ad_info = Db::getInstance()->executeS('SELECT description FROM `'._DB_PREFIX_.'businessdirectories_ads` WHERE `id_ad` = "'.(int)$id_ad.'"');

        //return $ad_info['description'];
    }
    
    public function displayCustomerName($id_customer) {
        $customer_info = Db::getInstance()->getRow('SELECT firstname, lastname FROM `'._DB_PREFIX_.'customer` WHERE `id_customer` = "'.(int)$id_customer.'"');
        return  $customer_info['firstname'].' '.$customer_info['lastname'];
    }
}
