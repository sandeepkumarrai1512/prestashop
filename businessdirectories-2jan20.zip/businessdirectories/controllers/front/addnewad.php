<?php
/**
* 2007-2019 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author    PrestaShop SA <contact@prestashop.com>
*  @copyright 2007-2019 PrestaShop SA
*  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

require_once(_PS_MODULE_DIR_ . 'businessdirectories/classes/AdsListing.php');
require_once(_PS_MODULE_DIR_ . 'businessdirectories/classes/TypesListing.php');
class BusinessdirectoriesAddNewAdModuleFrontController extends ModuleFrontControllerCore
{
    public function init()
    {
        $this->page_name = 'Add New Ad';
        $this->disableBlocks();
        parent::init();
    }

    protected function disableBlocks()
    {
        $this->display_column_left = false;
    }

    public function initContent()
    {
        parent::initContent();
        $obj = new TypesListing();

        $base_url = Tools::getHttpHost(true).__PS_BASE_URI__;

        
    if (!empty(Tools::getValue('delid'))) {

    $sql =   Db::getInstance()->getRow('SELECT name FROM `'._DB_PREFIX_.'businessdirectories_images` where id_image="'.Tools::getValue('delid').'" ');
    $target_dir = _PS_MODULE_DIR_."businessdirectories/uploads/";

    //$target_dir.$sql['name'];

    if (file_exists($target_dir.$sql['name'])) 
    {
    unlink($target_dir.$sql['name']);
    echo "File deleted Successfully ."; 
    

    $return_arr = array(); 
    Db::getInstance()->delete('businessdirectories_images', 'id_image = '.Tools::getValue('delid') );
    $return_arr = array(
        "msg" => 'success',
        "status" => 1
        );
    }else{
    echo "File does not exists"; 
    }

    echo json_encode($return_arr);
    }


    if (!empty($_FILES)) {
        
        $filetypeval = '';
                // Count total files
        //$countfiles = count($_FILES['images']['name']);

        $fileSizes = '';

        // Looping all files
     //for($i=0;$i<$countfiles;$i++){ 

        $target_dir = _PS_MODULE_DIR_."businessdirectories/uploads/";
                    $file_name = str_replace(" ","",basename( $_FILES['images']['name'] ) );
        /*$allowed = array("image/jpeg", "image/gif", "image/png", "image/jpg", "video/mp4",  "video/ogg", );
        if(!in_array($_FILES['images']['name'], $allowed)) {
                      //$error_message = 'in images only jpg, gif, png and in video mp4, ogg   files are allowed.';
                      $error = 'yes';

                      $return_arr = array("id" => $image_id,
                    "type" => $filetypeval,

                    "msg" => 'Sorry, In images only jpg, gif, png and in video mp4, ogg   files are allowed.',
                    "status" => 0
                    );
                    }*/

                    
                                       
                    if(!empty($file_name )){ 
                    $return_arr = array();

                    $file_name1 = rand().$file_name;

                    $target_file = $target_dir . $file_name1;

                    $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);


                    
                    
                    if( $imageFileType == "mp4" || $imageFileType == "webm" || $imageFileType == "wav" )
                    {
                        
                        $filetypeval = 1;
                    }else{
                      
                        $filetypeval = 0;  
                    } 

                    if( $_FILES['images']['size'] > 104857600 ){
                    
                    $return_arr = array("id" => $image_id,
                    "type" => $filetypeval,

                    "msg" => 'Sorry, your file is too large. You can upload files upto 100MB',
                    "status" => 0
                    );
                }else{



                        move_uploaded_file( $_FILES['images']['tmp_name'], $target_file);
                        
                    $add_new_img = Db::getInstance()->insert('businessdirectories_images', array(
                        'id_customer' => (int)$this->context->customer->id,
                        'name' => $file_name1,
                        'type' => $filetypeval,
                        'date_add' => date('Y-m-d')
                    ));

                    $image_id = Db::getInstance()->Insert_ID();
                    /*Db::getInstance()->insert('businessdirectories_ad_images', array(
                        'id_ad' => (int)$ad_id,
                        'id_image' => (int)$image_id
                    ));*/

                    $return_arr = array("id" => $image_id,
                    "type" => $filetypeval,
                    "msg" => 'File uploaded successfully.',
                    "imgsrc" => $file_name1,
                    "status" => 1
                    );
                }
                } 
                //} 
                // Encoding array in JSON format
            echo json_encode($return_arr);
                
            }         
        
        
        if (!empty(Tools::getValue('submitAd'))) {
       
		
		if(isset($_REQUEST['never_expire'])) {
		$_neverexpire='1';
		} else {
		$_neverexpire='';
		}

                



            $res = Db::getInstance()->insert('businessdirectories_ads', array(
                'id_customer' => (int)$this->context->customer->id,
                'id_shop' => (int)$this->context->shop->id,
                'title' => pSQL(Tools::getValue('title')),
                'description' => pSQL(htmlentities(Tools::getValue('description'))),
                'purchase_type' => pSQl(Tools::getValue('purchase_type')), 
                'currency_type' => Tools::getValue('currency_type'),
                'price_start' => pSQL(Tools::getValue('price_start')),
                'price_end' => pSQL(Tools::getValue('price_end')),
                'show_text' => pSQL(Tools::getValue('show_text')),
                'expire_date' => pSQL(Tools::getValue('expire_date')),
		        'never_expire' => $_neverexpire,
                'created_date' => date('Y-m-d')
            ));
            $ad_id = Db::getInstance()->Insert_ID();

            $redurl = $base_url."my-account/viewad?id_ad=".$ad_id;
            if (!empty($ad_id)) {
                foreach (Tools::getValue('types') as $single_type) {
                    $res = Db::getInstance()->insert('businessdirectories_ad_types', array(
                        'id_ad' => (int)$ad_id,
                        'id_type' => $single_type
                    ));
                }

                foreach (Tools::getValue('shipping_to') as $single_shipping) {
                    
                    $res_shipping = Db::getInstance()->insert('businessdirectories_ad_shipping', array(
                        'id_ad' => (int)$ad_id,
                        'id_shipping' => $single_shipping
                    ));
                }

            if (!empty(Tools::getValue('hiddenimages'))) {
                $hiddenimages = explode(',', Tools::getValue('hiddenimages'));
                              
                

                foreach ($hiddenimages as $single_imgid) {
                
                Db::getInstance()->insert('businessdirectories_ad_images', array(
                        'id_ad' => (int)$ad_id,
                        'id_image' => (int)$single_imgid
                    ));
                }
                
                

            }




            }
            $explode_tags = explode(',', Tools::getValue('tags'));
            foreach ($explode_tags as $single_tag) {
                // Tag name exist or not
                $checktag = $obj->checkTagExistOrNot($single_tag);
                if (!empty($checktag)) {
                    $tag_id = $checktag['id_tag'];
                } else {
                    $add_tag = Db::getInstance()->insert('businessdirectories_tags', array(
                        'name' => $single_tag,
                        'date_add' => date('Y-m-d')
                    ));
                    $tag_id = Db::getInstance()->Insert_ID();
                }
                Db::getInstance()->insert('businessdirectories_ad_tags', array(
                    'id_ad' => (int)$ad_id,
                    'id_tag' => (int)$tag_id
                ));
            }
            if (!empty(Tools::getValue('existing_images'))) {
                $explode_images_ids = explode(',', Tools::getValue('existing_images'));
                foreach ($explode_images_ids as $single_id) {
                    Db::getInstance()->insert('businessdirectories_ad_images', array(
                        'id_ad' => (int)$ad_id,
                        'id_image' => (int)$single_id
                    ));
                }
            }

            


            /*if (!empty($_FILES)) {
               
                $filetypeval = '';
                // Count total files
        $countfiles = count($_FILES['images']['name']);

        // Looping all files
     for($i=0;$i<$countfiles;$i++){    
                    
                    
                    $target_dir = _PS_MODULE_DIR_."businessdirectories/uploads/";
                    $file_name = str_replace(" ","",basename( $_FILES['images']['name'][$i] ) );

                    
                                       
                    if(!empty($file_name )){ 
                    $file_name1 = rand().$file_name;

                    $target_file = $target_dir . $file_name1;

                    $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
                    
                    if($imageFileType == "mp4" || $imageFileType == "mov" || $imageFileType == "3gp" || $imageFileType == "mpeg")
                    {
                        
                        $filetypeval = 1;
                    }else{
                      
                        $filetypeval = 0;  
                    } 
                    move_uploaded_file( $_FILES['images']['tmp_name'][$i], $target_file);
                    $add_new_img = Db::getInstance()->insert('businessdirectories_images', array(
                        'id_customer' => (int)$this->context->customer->id,
                        'name' => $file_name1,
                        'type' => $filetypeval,
                        'date_add' => date('Y-m-d')
                    ));
                    $image_id = Db::getInstance()->Insert_ID();
                    Db::getInstance()->insert('businessdirectories_ad_images', array(
                        'id_ad' => (int)$ad_id,
                        'id_image' => (int)$image_id
                    ));
                } 
                } 
            }*/

            
           sleep(4);
            $this->context->smarty->assign(array(
                'success' => 'Ad Successfully added',
            ));

           
            
            Tools::redirect($redurl);


        }
        
        
        $types = $obj->getAdTypes();
        $shippings = $obj->getAdShippings();

        $images = $obj->getAllImages((int)$this->context->customer->id);
        $videos = $obj->getAllVideos((int)$this->context->customer->id);
        if (!$this->context->customer->isLogged() && $this->php_self != 'authentication' && $this->php_self != 'password') {
            Tools::redirect('index.php?controller=authentication?back=my-account');
        } else {
            $object = new AdsListing();
            $base_url = Tools::getHttpHost(true).__PS_BASE_URI__;

                        
          
            
            $this->context->smarty->assign(array(
                'customer_id' => $this->context->customer->id,
                'base_url' => $base_url,
                'types' => $types,
                'shippings' => $shippings,
                'images' => $images,
                'videos' =>$videos
            ));
            if (Businessdirectories::isPs17()) {
                $this->setTemplate('module:businessdirectories/views/templates/front/add-ad.tpl');
            } else {
                $this->setTemplate('add-ad-1-6.tpl');
            }
        }
    }
    
    /**
     * @return array
     */
    public function getBreadcrumbLinks()
    {
        $breadcrumb = parent::getBreadcrumbLinks();
        $breadcrumb['links'][] = $this->addMyAccountToBreadcrumb();



        //return $breadcrumb;
    }
}
