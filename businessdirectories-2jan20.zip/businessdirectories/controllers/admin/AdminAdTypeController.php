<?php
/**
* 2007-2019 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author    PrestaShop SA <contact@prestashop.com>
*  @copyright 2007-2019 PrestaShop SA
*  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

require_once _PS_MODULE_DIR_.'businessdirectories/classes/TypesListing.php';
class AdminAdTypeController extends ModuleAdminController
{
    public $content = '';
    private $postErrors = array();
    public function __construct()
    {
        $this->context = Context::getContext();
        $this->bootstrap = true;

        parent::__construct();
        $this->toolbar_title = $this->l('Create New Ad Type');
    }

    /**
     * Initialize Content
     */
    public function initContent()
    {
        if (!empty($this->context->cookie->type_saved) || !empty($this->context->cookie->type_exist)) {
			$this->context->smarty->assign(array(
                'message' => (!empty($this->context->cookie->type_saved)) ? pSQL($this->context->cookie->type_saved) : pSQL($this->context->cookie->type_exist),
                'type' => (!empty($this->context->cookie->type_saved)) ? 1 : 2,
            ));
            $second_part_url = 'businessdirectories/views/templates/admin/success.tpl';
            $this->content .= $this->context->smarty->fetch(_PS_MODULE_DIR_.pSQL($second_part_url));
        }
        $this->content .= $this->renderForm();
        unset($this->context->cookie->type_saved);
        unset($this->context->cookie->type_exist);
        parent::initContent();
    }

    /**
     * Initialize Header Toolbar
     */
    public function initToolbar()
    {
        parent::initToolbar();
        $this->page_header_toolbar_btn['back_to_list'] = array(
            'href' => $this->context->link->getAdminLink('AdminAdsListing'),
            'desc' => $this->l('List Ad Types'),
            'icon' => 'process-icon-back',
        );
    }

    /**
     * Create the form that will be displayed in the controller page of your module.
     */
    public function renderForm()
    {
        $this->fields_form = array(
            'legend' => array(
                'title' => $this->l('Add New Type'),
                'icon' => 'icon-user',
            ),
            'input' => array(
                array(
                    'col' => 3,
                    'type' => 'text',
                    'label' => $this->l('Name'),
                    'name' => 'TYPE_NAME',
                    'required' => true,
                    'hint' => $this->l('Enter Type.'),
                    'desc' => $this->l('Enter type'),
                    'form_group_class' => 'businessdirectories',
                ),
            ),
            'submit' => array(
                'title' => $this->l('Save'),
                'name' => 'submitNewType',
            ),
        );

        $this->fields_value = array(
            'TYPE_NAME' => Tools::getValue('TYPE_NAME'),
        );

        return parent::renderForm();
    }

    /**
     * validate form data
     */
    protected function postValidation()
    {
        if (Tools::isSubmit('submitNewType')) {
            if (!Tools::getValue('TYPE_NAME')) {
                $this->postErrors[] = $this->l('Please Enter Type Name.');
            }
        }
    }

    /**
     * Check form value Int of Not
     */
    public function isInt($value)
    {
        return ((string)(int)$value === (string)$value or $value === false);
    }

    /**
     * Check form Value Float Or Not
     */
    public function isFloat($float)
    {
        return ((string)(float)$float == (string)$float);
    }

    /**
     * Display form Errors
     */
    public function displayError($err)
    {
        $this->errors[] = $err;
    }
    
    /**
     * Display form Warnings
     */
    public function displayWarning($warning)
    {
        $this->warning[] = $warning;
    }
    
    /**
     * Display form Confirmations
     */
    public function displayConfirmation($success)
    {
        $this->success[] = $success;
    }

    /**
     * Process form Data
     */
    public function postProcess()
    {
        if (Tools::isSubmit('submitNewType')) {
            $this->postValidation();
            if (!count($this->postErrors)) {
                // Check Type Name Exist
                $object = new TypesListing();
                $type_exist = $object->typeNameExistOrNot(pSQL(Tools::getValue('TYPE_NAME')));
                if (empty($type_exist)) {
                    Db::getInstance()->insert('businessdirectories_types', array(
                        'name' => pSQL(Tools::getValue('TYPE_NAME')),
                        'date_add' => date('Y-m-d H:i:s'),
                    ));
                    $this->context->cookie->__set('type_saved', 'Type name saved successfully');
                    Tools::redirectAdmin(self::$currentIndex . '&token=' . Tools::getAdminTokenLite('AdminAdType'));
                } else {
                    $warning = 'Type name already exist.';
                    $this->context->cookie->__set('type_exist', $warning);
                }
                parent::postProcess();
            } else {
                foreach ($this->postErrors as $err) {
                    $this->content .= $this->displayError($err);
                }
            }
        }
    }
}
