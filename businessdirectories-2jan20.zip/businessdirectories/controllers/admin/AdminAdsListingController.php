<?php
/**
* 2007-2019 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author    PrestaShop SA <contact@prestashop.com>
*  @copyright 2007-2019 PrestaShop SA
*  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

require_once _PS_MODULE_DIR_.'businessdirectories/classes/AdsListing.php';
class AdminAdsListingController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap = true;
        $this->table = 'businessdirectories_ads';
        $this->className = 'AdsListing';
        $this->identifier = 'id_ad';
        parent::__construct();
        $this->toolbar_title = $this->l('Manage All Ads');

        $this->fields_list = array(
            'title' => array(
                'title' => $this->l('Title'),
                'align' => 'center',
                'class' => 'fixed-width-xs',
                'search' => true,
                'width' => 100,
                'remove_onclick' => true,
            ),
            'description' => array(
                'title' => $this->l('Description'),
                'width' => '100',
                'search' => true,
                'remove_onclick' => true,
                'callback' => 'displayDescription',
            ),
            'purchase_type' => array(
                'title' => $this->l('Purchase Type'),
                'width' => '100',
                'remove_onclick' => true,
                'search' => true
            ),
            'id_ad' => array(
                'title' => $this->l('Price Range'),
                'width' => '100',
                'search' => true,
                'remove_onclick' => true,
                'callback' => 'displayPriceRange'
            ),
            'show_text' => array(
                'title' => $this->l('Show'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'expire_date' => array(
                'title' => $this->l('Expiry Date'),
                'width' => '100',
                'search' => false,
                'remove_onclick' => true,
            ),
            'id_customer' => array(
                'title' => $this->l('Customer Name'),
                'width' => '100',
                'search' => true,
                'remove_onclick' => true,
                'callback' => 'displayCustomerName'
            ),
        );
        $this->bulk_actions = array(
            'delete' => array('text' => $this->l('Delete selected'),
                'icon' => 'icon-trash',
                'confirm' => $this->l('Delete selected Ad?'),
            ),
        );
    }

    /**
     * Initialize Header Toolbar
     */
    public function initToolbar()
    {
        parent::initToolbar();
    }

    /**
     * Initialize Results Action
     */
    public function renderList()
    {
        $this->addRowAction('delete');
        return parent::renderList();
    }
    
    public function displayPriceRange($id_ad) {
        $ad_info = Db::getInstance()->getRow('SELECT price_start, price_end FROM `'._DB_PREFIX_.'businessdirectories_ads` WHERE `id_ad` = "'.(int)$id_ad.'"');
        return Tools::displayPrice($ad_info['price_start']).' - '.Tools::displayPrice($ad_info['price_end']);
    }

    public function displayDescription($desc) {
        return html_entity_decode($desc);      
        //$ad_info = Db::getInstance()->executeS('SELECT description FROM `'._DB_PREFIX_.'businessdirectories_ads` WHERE `id_ad` = "'.(int)$id_ad.'"');

        //return $ad_info['description'];
    }
    
    public function displayCustomerName($id_customer) {
		$customer_info = Db::getInstance()->getRow('SELECT firstname, lastname FROM `'._DB_PREFIX_.'customer` WHERE `id_customer` = "'.(int)$id_customer.'"');
        return  $customer_info['firstname'].' '.$customer_info['lastname'];
    }
}
