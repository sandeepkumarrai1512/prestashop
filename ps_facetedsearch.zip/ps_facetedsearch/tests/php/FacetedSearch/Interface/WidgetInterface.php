<?php

namespace PrestaShop\PrestaShop\Core\Module;

interface WidgetInterface
{
}
