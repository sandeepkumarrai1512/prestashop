<?php
/**
* 2007-2019 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author    PrestaShop SA <contact@prestashop.com>
*  @copyright 2007-2019 PrestaShop SA
*  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

include(dirname(__FILE__) . '/../../config/config.inc.php');

if (Tools::getValue('type')=='showexistingimages') {
    $html = '';
    if (!empty(Tools::getValue('existing_images'))) {
        $explode_images = explode(',', Tools::getValue('existing_images'));
        foreach ($explode_images as $single_img) {
            $html.=getImage($single_img);
        }
    }
    echo $html;
}

function getImage($id)
{
    $res = Db::getInstance()->getRow('SELECT * FROM `'._DB_PREFIX_.'businessdirectories_images`as bi where bi.id_image="'.$id.'"');
	return '<img src="'.Tools::getValue('base_url').'modules/businessdirectories/uploads/'.$res['name'].'" style="width:100px;margin-right:10px;float:left;">';
}
exit;
